'use strict';

module.exports = require('assert');
