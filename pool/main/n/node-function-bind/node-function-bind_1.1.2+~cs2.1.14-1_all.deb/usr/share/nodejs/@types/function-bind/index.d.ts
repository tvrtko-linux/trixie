import bind = require("./implementation");
export = bind;
