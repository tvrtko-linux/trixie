# Installation
> `npm install --save @types/retry`

# Summary
This package contains type definitions for retry (https://github.com/tim-kos/node-retry).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/retry.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: none

# Credits
These definitions were written by [Stan Goldmann](https://github.com/krenor), and [BendingBender](https://github.com/BendingBender).
