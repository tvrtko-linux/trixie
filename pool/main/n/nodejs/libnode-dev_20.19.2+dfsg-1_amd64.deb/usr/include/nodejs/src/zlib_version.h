// This is an auto generated file, please do not edit.
// Refer to tools/dep_updaters/update-zlib.sh
#ifndef SRC_ZLIB_VERSION_H_
#define SRC_ZLIB_VERSION_H_
#define ZLIB_VERSION "1.3.0.1-motley-82a5fec"
#endif  // SRC_ZLIB_VERSION_H_
