// This is an auto generated file, please do not edit.
// Refer to tools/dep_updaters/update-undici.sh
#ifndef SRC_UNDICI_VERSION_H_
#define SRC_UNDICI_VERSION_H_
#define UNDICI_VERSION "7.3.0"
#endif  // SRC_UNDICI_VERSION_H_
