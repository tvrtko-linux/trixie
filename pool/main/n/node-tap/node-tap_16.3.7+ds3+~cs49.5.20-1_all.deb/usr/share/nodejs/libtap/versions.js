'use strict'

module.exports = {
  libtap: require('./package.json').version,
  tapParser: require('tap-parser/package.json').version,
  tapYaml: require('tap-yaml/package.json').version,
  tcompare: require('tcompare/package.json').version
}
