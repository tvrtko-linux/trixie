/* eslint-disable @definitelytyped/no-useless-files */

// For following usage:
//    import 'source-map-support/register'
// Instead of:
//    import sourceMapSupport from 'source-map-support'
//    sourceMapSupport.install()
