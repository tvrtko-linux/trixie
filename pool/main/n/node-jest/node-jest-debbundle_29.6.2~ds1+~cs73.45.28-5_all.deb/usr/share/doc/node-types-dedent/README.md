# Installation
> `npm install --save @types/dedent`

# Summary
This package contains type definitions for dedent (https://github.com/dmnd/dedent).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/dedent

Additional Details
 * Last updated: Fri, 30 Jun 2017 21:28:45 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Douglas Duteil <https://github.com/douglasduteil>.
