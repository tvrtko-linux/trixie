'use strict';

var test = require('tape');
test(function (t) {
	t.plan(1);
	t.equal('beep', 'boop');
});
