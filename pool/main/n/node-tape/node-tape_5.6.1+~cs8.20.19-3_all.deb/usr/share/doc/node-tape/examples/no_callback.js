'use strict';

var test = require('tape');

test('No cb test');
