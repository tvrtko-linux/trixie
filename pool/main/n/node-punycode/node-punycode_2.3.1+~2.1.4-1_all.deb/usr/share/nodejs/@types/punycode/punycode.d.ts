import punycode = require(".");
export = punycode;
