# @babel/plugin-transform-react-inline-elements

> Turn JSX elements into exploded React objects

See our website [@babel/plugin-transform-react-inline-elements](https://babeljs.io/docs/en/babel-plugin-transform-react-inline-elements) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-react-inline-elements
```

or using yarn:

```sh
yarn add @babel/plugin-transform-react-inline-elements --dev
```
