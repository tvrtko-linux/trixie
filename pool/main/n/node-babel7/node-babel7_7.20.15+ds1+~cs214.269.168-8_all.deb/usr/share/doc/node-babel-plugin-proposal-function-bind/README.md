# @babel/plugin-proposal-function-bind

> Compile function bind operator to ES5

See our website [@babel/plugin-proposal-function-bind](https://babeljs.io/docs/en/babel-plugin-proposal-function-bind) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-function-bind
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-function-bind --dev
```
