# @babel/plugin-transform-react-jsx

> Turn JSX into React function calls

See our website [@babel/plugin-transform-react-jsx](https://babeljs.io/docs/en/babel-plugin-transform-react-jsx) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-react-jsx
```

or using yarn:

```sh
yarn add @babel/plugin-transform-react-jsx --dev
```
