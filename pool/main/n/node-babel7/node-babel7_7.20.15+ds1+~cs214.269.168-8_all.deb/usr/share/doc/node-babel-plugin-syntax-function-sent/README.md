# @babel/plugin-syntax-function-sent

> Allow parsing of the function.sent meta property

See our website [@babel/plugin-syntax-function-sent](https://babeljs.io/docs/en/babel-plugin-syntax-function-sent) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-function-sent
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-function-sent --dev
```
