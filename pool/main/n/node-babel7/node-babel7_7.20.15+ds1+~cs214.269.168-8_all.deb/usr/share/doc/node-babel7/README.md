# Documentation moved

node-babel7 is now built using dh-nodejs-autodocs, then each README.md is
stored in usr/share/doc/node-\<component-normalized-name\>
