# @babel/plugin-syntax-import-reflection

> Allow parsing of the reflection attributes in the import statement

See our website [@babel/plugin-syntax-import-reflection](https://babeljs.io/docs/en/babel-plugin-syntax-import-reflection) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-import-reflection
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-import-reflection --dev
```
