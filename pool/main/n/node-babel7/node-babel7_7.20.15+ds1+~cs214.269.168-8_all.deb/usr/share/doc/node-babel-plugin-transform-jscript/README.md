# @babel/plugin-transform-jscript

> Babel plugin to fix buggy JScript named function expressions

See our website [@babel/plugin-transform-jscript](https://babeljs.io/docs/en/babel-plugin-transform-jscript) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-jscript
```

or using yarn:

```sh
yarn add @babel/plugin-transform-jscript --dev
```
