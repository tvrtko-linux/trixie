# @babel/plugin-transform-react-jsx-compat

> Turn JSX into React Pre-0.12 function calls

See our website [@babel/plugin-transform-react-jsx-compat](https://babeljs.io/docs/en/babel-plugin-transform-react-jsx-compat) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-react-jsx-compat
```

or using yarn:

```sh
yarn add @babel/plugin-transform-react-jsx-compat --dev
```
