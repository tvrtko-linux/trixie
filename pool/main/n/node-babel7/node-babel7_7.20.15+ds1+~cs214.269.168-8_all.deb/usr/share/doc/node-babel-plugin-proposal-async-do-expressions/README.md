# @babel/plugin-proposal-async-do-expressions

> Transform async do expressions to ES2021

See our website [@babel/plugin-proposal-async-do-expressions](https://babeljs.io/docs/en/babel-plugin-proposal-async-do-expressions) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-async-do-expressions
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-async-do-expressions --dev
```
