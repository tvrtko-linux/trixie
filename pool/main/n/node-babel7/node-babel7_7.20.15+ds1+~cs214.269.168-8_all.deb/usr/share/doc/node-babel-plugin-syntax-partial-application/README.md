# @babel/plugin-syntax-partial-application

> Allow parsing of partial application syntax

See our website [@babel/plugin-syntax-partial-application](https://babeljs.io/docs/en/babel-plugin-syntax-partial-application) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-partial-application
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-partial-application --dev
```
