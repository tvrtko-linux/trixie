# @babel/plugin-syntax-destructuring-private

> Allow parsing of destructuring private fields

See our website [@babel/plugin-syntax-destructuring-private](https://babeljs.io/docs/en/babel-plugin-syntax-destructuring-private) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-destructuring-private
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-destructuring-private --dev
```
