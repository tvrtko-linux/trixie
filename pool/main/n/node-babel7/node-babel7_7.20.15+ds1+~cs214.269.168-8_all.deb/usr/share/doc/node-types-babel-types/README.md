# Installation
> `npm install --save @types/babel-types`

# Summary
This package contains type definitions for babel-types (https://github.com/babel/babel/tree/master/packages/babel-types).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel-types.

### Additional Details
 * Last updated: Thu, 26 Aug 2021 01:01:27 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Troy Gerwien](https://github.com/yortus), [Sam Baxter](https://github.com/baxtersa), [Marvin Hagemeister](https://github.com/marvinhagemeister), [Boris Cherny](https://github.com/bcherny), and [ExE Boss](https://github.com/ExE-Boss).
