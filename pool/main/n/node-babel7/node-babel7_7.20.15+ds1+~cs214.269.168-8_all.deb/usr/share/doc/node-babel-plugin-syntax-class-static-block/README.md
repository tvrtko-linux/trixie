# @babel/plugin-syntax-class-static-block

> Allow parsing of class static blocks

See our website [@babel/plugin-syntax-class-static-block](https://babeljs.io/docs/en/babel-plugin-syntax-class-static-block) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-class-static-block
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-class-static-block --dev
```
