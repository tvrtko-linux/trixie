# @babel/helper-fixtures

> Helper function to support fixtures

See our website [@babel/helper-fixtures](https://babeljs.io/docs/en/babel-helper-fixtures) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-fixtures
```

or using yarn:

```sh
yarn add @babel/helper-fixtures
```
