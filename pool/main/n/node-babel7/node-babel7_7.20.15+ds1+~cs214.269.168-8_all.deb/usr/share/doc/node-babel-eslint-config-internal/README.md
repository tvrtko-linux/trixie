## @babel/eslint-config-internal
---

ESLint config for the Babel codebase (originally taken from `eslint-config-kittens`)
