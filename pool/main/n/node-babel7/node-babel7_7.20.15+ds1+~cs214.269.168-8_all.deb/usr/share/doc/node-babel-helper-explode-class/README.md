# @babel/helper-explode-class

> Helper function to explode class

See our website [@babel/helper-explode-class](https://babeljs.io/docs/en/babel-helper-explode-class) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-explode-class
```

or using yarn:

```sh
yarn add @babel/helper-explode-class --dev
```
