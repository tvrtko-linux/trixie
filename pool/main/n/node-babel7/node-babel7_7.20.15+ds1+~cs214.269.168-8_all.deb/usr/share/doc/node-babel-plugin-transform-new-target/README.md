# @babel/plugin-transform-new-target

> Transforms new.target meta property

See our website [@babel/plugin-transform-new-target](https://babeljs.io/docs/en/babel-plugin-transform-new-target) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-new-target
```

or using yarn:

```sh
yarn add @babel/plugin-transform-new-target --dev
```
