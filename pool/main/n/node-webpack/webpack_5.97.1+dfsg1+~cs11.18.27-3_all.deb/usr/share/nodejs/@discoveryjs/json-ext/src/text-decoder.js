module.exports = require('util').TextDecoder;
