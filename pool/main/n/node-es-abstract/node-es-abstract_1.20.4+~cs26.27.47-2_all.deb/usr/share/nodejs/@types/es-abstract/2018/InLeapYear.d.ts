import InLeapYear = require('../2017/InLeapYear');
export = InLeapYear;
