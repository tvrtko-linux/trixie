import IsDataDescriptor = require('../2016/IsDataDescriptor');
export = IsDataDescriptor;
