import MakeDate = require('../2015/MakeDate');
export = MakeDate;
