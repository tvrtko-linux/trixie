declare function EnumerableOwnNames<O extends object>(target: O): Array<keyof O>;
export = EnumerableOwnNames;
