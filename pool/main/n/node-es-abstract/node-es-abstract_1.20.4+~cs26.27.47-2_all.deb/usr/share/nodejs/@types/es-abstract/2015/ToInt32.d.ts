import ToInt32 = require('../5/ToInt32');
export = ToInt32;
