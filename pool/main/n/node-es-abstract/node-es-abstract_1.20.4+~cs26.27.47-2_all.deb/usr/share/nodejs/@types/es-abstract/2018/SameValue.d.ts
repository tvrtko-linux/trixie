import SameValue = require('../2017/SameValue');
export = SameValue;
