import MakeDay = require('../5/MakeDay');
export = MakeDay;
