import ToPropertyDescriptor = require('../2015/ToPropertyDescriptor');
export = ToPropertyDescriptor;
