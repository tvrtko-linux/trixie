import DayWithinYear = require('../2018/DayWithinYear');
export = DayWithinYear;
