import thisStringValue = require('../2016/thisStringValue');
export = thisStringValue;
