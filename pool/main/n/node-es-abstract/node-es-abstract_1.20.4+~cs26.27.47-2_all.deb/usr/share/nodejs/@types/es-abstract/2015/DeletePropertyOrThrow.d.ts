import type { PropertyKey } from '../index';

declare function DeletePropertyOrThrow(O: object, P: PropertyKey): boolean;
export = DeletePropertyOrThrow;
