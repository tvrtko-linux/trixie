import DayWithinYear = require('../2016/DayWithinYear');
export = DayWithinYear;
