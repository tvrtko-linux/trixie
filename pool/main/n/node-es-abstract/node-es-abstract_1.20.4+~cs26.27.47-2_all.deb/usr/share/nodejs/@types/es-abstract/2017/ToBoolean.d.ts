import ToBoolean = require('../2016/ToBoolean');
export = ToBoolean;
