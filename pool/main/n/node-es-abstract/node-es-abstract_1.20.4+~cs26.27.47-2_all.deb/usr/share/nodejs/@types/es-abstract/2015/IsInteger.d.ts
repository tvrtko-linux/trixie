declare function IsInteger(argument: unknown): argument is number;
export = IsInteger;
