import type { PropertyKey } from '../index';

declare function CreateMethodProperty(O: object, P: PropertyKey, V: unknown): boolean;
export = CreateMethodProperty;
