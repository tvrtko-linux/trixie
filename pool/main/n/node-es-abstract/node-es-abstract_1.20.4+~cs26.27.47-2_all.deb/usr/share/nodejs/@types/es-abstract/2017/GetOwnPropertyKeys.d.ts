import GetOwnPropertyKeys = require('../2016/GetOwnPropertyKeys');
export = GetOwnPropertyKeys;
