declare function ToLength(value: unknown): number;
export = ToLength;
