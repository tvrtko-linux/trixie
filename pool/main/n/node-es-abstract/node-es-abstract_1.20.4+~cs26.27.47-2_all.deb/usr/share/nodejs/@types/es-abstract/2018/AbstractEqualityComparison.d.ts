import AbstractEqualityComparison = require('../2017/AbstractEqualityComparison');
export = AbstractEqualityComparison;
