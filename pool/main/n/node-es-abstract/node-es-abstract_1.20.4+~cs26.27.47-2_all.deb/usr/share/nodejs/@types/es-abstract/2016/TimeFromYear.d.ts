import TimeFromYear = require('../2015/TimeFromYear');
export = TimeFromYear;
