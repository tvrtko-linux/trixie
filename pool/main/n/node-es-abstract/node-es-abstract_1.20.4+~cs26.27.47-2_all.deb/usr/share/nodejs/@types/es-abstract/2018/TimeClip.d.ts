import TimeClip = require('../2017/TimeClip');
export = TimeClip;
