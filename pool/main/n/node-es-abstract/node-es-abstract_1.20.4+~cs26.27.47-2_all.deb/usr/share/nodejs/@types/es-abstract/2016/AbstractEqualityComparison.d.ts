import AbstractEqualityComparison = require('../2015/AbstractEqualityComparison');
export = AbstractEqualityComparison;
