import ToUint32 = require('../2015/ToUint32');
export = ToUint32;
