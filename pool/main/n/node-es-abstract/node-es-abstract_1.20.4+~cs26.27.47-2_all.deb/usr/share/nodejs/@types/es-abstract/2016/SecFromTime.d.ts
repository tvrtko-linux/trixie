import SecFromTime = require('../2015/SecFromTime');
export = SecFromTime;
