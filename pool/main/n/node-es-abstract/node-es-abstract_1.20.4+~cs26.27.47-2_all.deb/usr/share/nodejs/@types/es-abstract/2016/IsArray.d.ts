import IsArray = require('../2015/IsArray');
export = IsArray;
