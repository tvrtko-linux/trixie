import IsRegExp = require('../2015/IsRegExp');
export = IsRegExp;
