import SameValueZero = require('../2015/SameValueZero');
export = SameValueZero;
