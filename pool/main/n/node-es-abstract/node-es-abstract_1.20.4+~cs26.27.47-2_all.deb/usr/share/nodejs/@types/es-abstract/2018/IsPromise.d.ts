import IsPromise = require('../2017/IsPromise');
export = IsPromise;
