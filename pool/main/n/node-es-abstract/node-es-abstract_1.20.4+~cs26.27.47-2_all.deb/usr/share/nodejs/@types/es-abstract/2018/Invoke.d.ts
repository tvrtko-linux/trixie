import Invoke = require('../2017/Invoke');
export = Invoke;
