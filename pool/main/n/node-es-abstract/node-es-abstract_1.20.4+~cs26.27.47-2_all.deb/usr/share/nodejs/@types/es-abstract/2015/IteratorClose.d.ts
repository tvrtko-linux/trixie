declare function IteratorClose<T>(iterator: Iterator<unknown, unknown, unknown>, completion: () => T): T;
export = IteratorClose;
