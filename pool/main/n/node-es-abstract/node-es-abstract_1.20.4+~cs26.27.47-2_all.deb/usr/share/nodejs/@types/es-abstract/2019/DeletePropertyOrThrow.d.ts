import DeletePropertyOrThrow = require('../2018/DeletePropertyOrThrow');
export = DeletePropertyOrThrow;
