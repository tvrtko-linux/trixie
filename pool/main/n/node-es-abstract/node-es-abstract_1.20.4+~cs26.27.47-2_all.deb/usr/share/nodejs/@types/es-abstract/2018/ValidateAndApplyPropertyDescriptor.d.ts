import ValidateAndApplyPropertyDescriptor = require('../2017/ValidateAndApplyPropertyDescriptor');
export = ValidateAndApplyPropertyDescriptor;
