import ToBoolean = require('../2017/ToBoolean');
export = ToBoolean;
