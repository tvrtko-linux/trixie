import CreateIterResultObject = require('../2018/CreateIterResultObject');
export = CreateIterResultObject;
