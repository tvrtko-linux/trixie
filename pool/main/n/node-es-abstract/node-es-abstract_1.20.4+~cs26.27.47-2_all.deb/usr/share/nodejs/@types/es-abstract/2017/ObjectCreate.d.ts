import ObjectCreate = require('../2016/ObjectCreate');
export = ObjectCreate;
