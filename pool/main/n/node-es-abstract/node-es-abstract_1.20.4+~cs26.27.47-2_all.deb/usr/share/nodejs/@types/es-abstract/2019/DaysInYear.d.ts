import DaysInYear = require('../2018/DaysInYear');
export = DaysInYear;
