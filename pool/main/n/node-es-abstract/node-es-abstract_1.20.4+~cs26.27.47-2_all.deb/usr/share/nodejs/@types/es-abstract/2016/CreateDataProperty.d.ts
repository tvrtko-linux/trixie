import CreateDataProperty = require('../2015/CreateDataProperty');
export = CreateDataProperty;
