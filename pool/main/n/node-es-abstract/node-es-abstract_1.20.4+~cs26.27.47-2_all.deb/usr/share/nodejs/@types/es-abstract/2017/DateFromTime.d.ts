import DateFromTime = require('../2016/DateFromTime');
export = DateFromTime;
