declare const IsExtensible: typeof Object.isExtensible;
export = IsExtensible;
