import YearFromTime = require('../2017/YearFromTime');
export = YearFromTime;
