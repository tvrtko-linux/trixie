import MakeTime = require('../2015/MakeTime');
export = MakeTime;
