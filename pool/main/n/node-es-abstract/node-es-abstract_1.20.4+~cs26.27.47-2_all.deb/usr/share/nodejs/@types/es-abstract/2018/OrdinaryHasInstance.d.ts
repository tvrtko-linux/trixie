import OrdinaryHasInstance = require('../2017/OrdinaryHasInstance');
export = OrdinaryHasInstance;
