import IteratorClose = require('../2017/IteratorClose');
export = IteratorClose;
