import IsPromise = require('../2018/IsPromise');
export = IsPromise;
