import IsRegExp = require('../2017/IsRegExp');
export = IsRegExp;
