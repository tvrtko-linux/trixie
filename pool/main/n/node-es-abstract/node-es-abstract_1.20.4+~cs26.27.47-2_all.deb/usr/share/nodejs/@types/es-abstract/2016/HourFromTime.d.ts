import HourFromTime = require('../2015/HourFromTime');
export = HourFromTime;
