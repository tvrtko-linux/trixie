import CreateIterResultObject = require('../2015/CreateIterResultObject');
export = CreateIterResultObject;
