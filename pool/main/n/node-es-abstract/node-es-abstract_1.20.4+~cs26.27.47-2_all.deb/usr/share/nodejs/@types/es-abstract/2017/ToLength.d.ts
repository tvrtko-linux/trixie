import ToLength = require('../2016/ToLength');
export = ToLength;
