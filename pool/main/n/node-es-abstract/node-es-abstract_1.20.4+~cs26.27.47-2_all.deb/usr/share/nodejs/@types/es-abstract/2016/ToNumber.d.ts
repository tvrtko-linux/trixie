import ToNumber = require('../2015/ToNumber');
export = ToNumber;
