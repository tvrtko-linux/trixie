import GetIterator = require('../2015/GetIterator');
export = GetIterator;
