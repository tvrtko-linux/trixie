import IsPropertyKey = require('../2015/IsPropertyKey');
export = IsPropertyKey;
