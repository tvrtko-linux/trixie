import IsInteger = require('../2018/IsInteger');
export = IsInteger;
