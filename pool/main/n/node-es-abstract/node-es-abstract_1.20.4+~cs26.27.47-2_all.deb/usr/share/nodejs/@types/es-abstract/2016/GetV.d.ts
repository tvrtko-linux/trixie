import GetV = require('../2015/GetV');
export = GetV;
