import InLeapYear = require('../2018/InLeapYear');
export = InLeapYear;
