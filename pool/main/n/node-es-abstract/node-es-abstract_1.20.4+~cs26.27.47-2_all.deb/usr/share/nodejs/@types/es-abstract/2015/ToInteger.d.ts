import ToInteger = require('../5/ToInteger');
export = ToInteger;
