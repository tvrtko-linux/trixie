declare function IteratorStep<T>(iterator: Iterator<T>): IteratorYieldResult<T> | false;
export = IteratorStep;
