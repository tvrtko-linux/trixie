import ToObject = require('../2016/ToObject');
export = ToObject;
