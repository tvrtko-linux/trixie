import InstanceofOperator = require('../2017/InstanceofOperator');
export = InstanceofOperator;
