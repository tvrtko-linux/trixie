import DayWithinYear = require('../2015/DayWithinYear');
export = DayWithinYear;
