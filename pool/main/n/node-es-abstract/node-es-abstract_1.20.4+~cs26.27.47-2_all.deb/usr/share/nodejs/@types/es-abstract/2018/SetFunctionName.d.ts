import SetFunctionName = require('../2017/SetFunctionName');
export = SetFunctionName;
