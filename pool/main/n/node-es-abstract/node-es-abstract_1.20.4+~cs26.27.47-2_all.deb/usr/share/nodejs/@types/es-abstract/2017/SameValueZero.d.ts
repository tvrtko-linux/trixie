import SameValueZero = require('../2016/SameValueZero');
export = SameValueZero;
