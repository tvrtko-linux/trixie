// tslint:disable-next-line: ban-types
declare function thisStringValue(value: string | String): string;
export = thisStringValue;
