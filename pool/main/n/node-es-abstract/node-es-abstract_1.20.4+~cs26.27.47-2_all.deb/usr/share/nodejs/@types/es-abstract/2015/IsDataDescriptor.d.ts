import IsDataDescriptor = require('../5/IsDataDescriptor');
export = IsDataDescriptor;
