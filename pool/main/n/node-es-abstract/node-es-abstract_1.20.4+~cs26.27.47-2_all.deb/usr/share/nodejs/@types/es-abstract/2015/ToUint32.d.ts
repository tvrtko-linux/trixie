import ToUint32 = require('../5/ToUint32');
export = ToUint32;
