import IteratorValue = require('../2016/IteratorValue');
export = IteratorValue;
