import GetV = require('../2016/GetV');
export = GetV;
