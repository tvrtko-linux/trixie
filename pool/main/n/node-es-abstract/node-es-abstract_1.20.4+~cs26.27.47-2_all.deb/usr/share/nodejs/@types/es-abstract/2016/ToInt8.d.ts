import ToInt8 = require('../2015/ToInt8');
export = ToInt8;
