import SameValue = require('../2015/SameValue');
export = SameValue;
