import ToPropertyKey = require('../2016/ToPropertyKey');
export = ToPropertyKey;
