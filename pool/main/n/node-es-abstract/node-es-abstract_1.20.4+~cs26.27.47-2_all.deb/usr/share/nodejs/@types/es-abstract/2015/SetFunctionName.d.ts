// tslint:disable-next-line: ban-types
declare function SetFunctionName(F: Function, name: string | symbol, prefix?: string): boolean;
export = SetFunctionName;
