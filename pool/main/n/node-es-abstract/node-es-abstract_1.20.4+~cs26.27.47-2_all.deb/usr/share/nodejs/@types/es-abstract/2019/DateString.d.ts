import DateString = require('../2018/DateString');
export = DateString;
