import DeletePropertyOrThrow = require('../2015/DeletePropertyOrThrow');
export = DeletePropertyOrThrow;
