import CompletePropertyDescriptor = require('../2015/CompletePropertyDescriptor');
export = CompletePropertyDescriptor;
