import thisTimeValue = require('../2015/thisTimeValue');
export = thisTimeValue;
