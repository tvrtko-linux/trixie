import CreateDataPropertyOrThrow = require('../2016/CreateDataPropertyOrThrow');
export = CreateDataPropertyOrThrow;
