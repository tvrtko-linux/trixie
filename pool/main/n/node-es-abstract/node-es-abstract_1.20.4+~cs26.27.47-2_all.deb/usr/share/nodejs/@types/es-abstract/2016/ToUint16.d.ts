import ToUint16 = require('../2015/ToUint16');
export = ToUint16;
