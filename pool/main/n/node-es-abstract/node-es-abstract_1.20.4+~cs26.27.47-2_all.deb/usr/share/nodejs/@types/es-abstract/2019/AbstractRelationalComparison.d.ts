import AbstractRelationalComparison = require('../2018/AbstractRelationalComparison');
export = AbstractRelationalComparison;
