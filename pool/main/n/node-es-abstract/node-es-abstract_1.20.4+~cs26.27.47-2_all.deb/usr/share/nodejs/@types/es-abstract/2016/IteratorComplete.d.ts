import IteratorComplete = require('../2015/IteratorComplete');
export = IteratorComplete;
