import ToNumber = require('../2016/ToNumber');
export = ToNumber;
