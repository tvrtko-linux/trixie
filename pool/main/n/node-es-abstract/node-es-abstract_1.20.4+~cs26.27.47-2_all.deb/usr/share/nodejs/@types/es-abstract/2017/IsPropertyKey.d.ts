import IsPropertyKey = require('../2016/IsPropertyKey');
export = IsPropertyKey;
