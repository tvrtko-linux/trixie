import CreateMethodProperty = require('../2018/CreateMethodProperty');
export = CreateMethodProperty;
