import DeletePropertyOrThrow = require('../2017/DeletePropertyOrThrow');
export = DeletePropertyOrThrow;
