import OrdinaryDefineOwnProperty = require('../2017/OrdinaryDefineOwnProperty');
export = OrdinaryDefineOwnProperty;
