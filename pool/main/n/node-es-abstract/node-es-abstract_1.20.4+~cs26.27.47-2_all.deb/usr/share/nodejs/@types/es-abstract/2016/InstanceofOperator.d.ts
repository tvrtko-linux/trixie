import InstanceofOperator = require('../2015/InstanceofOperator');
export = InstanceofOperator;
