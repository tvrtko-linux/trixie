import ToUint8Clamp = require('../2015/ToUint8Clamp');
export = ToUint8Clamp;
