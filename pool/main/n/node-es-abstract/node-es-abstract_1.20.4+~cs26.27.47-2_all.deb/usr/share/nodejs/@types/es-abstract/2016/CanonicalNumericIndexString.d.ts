import CanonicalNumericIndexString = require('../2015/CanonicalNumericIndexString');
export = CanonicalNumericIndexString;
