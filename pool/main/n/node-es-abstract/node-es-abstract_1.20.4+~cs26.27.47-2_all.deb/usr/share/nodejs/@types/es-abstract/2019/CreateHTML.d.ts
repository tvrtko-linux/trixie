import CreateHTML = require('../2018/CreateHTML');
export = CreateHTML;
