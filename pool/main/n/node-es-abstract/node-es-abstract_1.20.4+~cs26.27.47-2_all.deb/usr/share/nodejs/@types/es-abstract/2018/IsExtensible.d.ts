import IsExtensible = require('../2017/IsExtensible');
export = IsExtensible;
