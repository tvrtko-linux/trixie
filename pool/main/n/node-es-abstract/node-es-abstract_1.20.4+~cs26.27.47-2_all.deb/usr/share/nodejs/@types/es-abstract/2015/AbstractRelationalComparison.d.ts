import AbstractRelationalComparison = require('../5/AbstractRelationalComparison');
export = AbstractRelationalComparison;
