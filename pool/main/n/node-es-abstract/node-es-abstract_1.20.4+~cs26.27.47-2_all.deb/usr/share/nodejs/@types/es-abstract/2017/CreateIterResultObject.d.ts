import CreateIterResultObject = require('../2016/CreateIterResultObject');
export = CreateIterResultObject;
