import ToUint8 = require('../2015/ToUint8');
export = ToUint8;
