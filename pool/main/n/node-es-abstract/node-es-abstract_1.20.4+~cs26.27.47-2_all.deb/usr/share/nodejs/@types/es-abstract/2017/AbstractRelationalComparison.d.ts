import AbstractRelationalComparison = require('../2016/AbstractRelationalComparison');
export = AbstractRelationalComparison;
