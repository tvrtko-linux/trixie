import IteratorStep = require('../2015/IteratorStep');
export = IteratorStep;
