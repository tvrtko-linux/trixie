import GetMethod = require('../2015/GetMethod');
export = GetMethod;
