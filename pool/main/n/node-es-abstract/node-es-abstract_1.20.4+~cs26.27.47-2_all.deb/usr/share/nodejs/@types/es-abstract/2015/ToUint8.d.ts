declare function ToUint8(value: unknown): number;
export = ToUint8;
