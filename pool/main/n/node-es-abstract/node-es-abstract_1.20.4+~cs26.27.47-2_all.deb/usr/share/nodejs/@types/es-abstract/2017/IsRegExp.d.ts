import IsRegExp = require('../2016/IsRegExp');
export = IsRegExp;
