import IsPropertyDescriptor = require('../5/IsPropertyDescriptor');
export = IsPropertyDescriptor;
