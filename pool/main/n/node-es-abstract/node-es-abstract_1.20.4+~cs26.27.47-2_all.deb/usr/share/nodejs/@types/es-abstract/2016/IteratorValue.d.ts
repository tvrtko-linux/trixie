import IteratorValue = require('../2015/IteratorValue');
export = IteratorValue;
