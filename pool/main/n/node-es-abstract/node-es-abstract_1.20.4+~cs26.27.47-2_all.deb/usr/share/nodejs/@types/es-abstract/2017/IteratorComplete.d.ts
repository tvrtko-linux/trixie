import IteratorComplete = require('../2016/IteratorComplete');
export = IteratorComplete;
