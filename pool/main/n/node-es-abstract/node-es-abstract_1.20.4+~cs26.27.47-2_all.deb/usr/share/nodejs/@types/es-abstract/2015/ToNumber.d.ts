import ToNumber = require('../5/ToNumber');
export = ToNumber;
