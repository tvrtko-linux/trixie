import ToDateString = require('../2015/ToDateString');
export = ToDateString;
