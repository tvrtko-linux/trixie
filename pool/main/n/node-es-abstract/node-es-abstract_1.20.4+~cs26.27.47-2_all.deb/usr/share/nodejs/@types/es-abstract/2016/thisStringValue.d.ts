import thisStringValue = require('../2015/thisStringValue');
export = thisStringValue;
