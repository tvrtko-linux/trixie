import DayWithinYear = require('../5/DayWithinYear');
export = DayWithinYear;
