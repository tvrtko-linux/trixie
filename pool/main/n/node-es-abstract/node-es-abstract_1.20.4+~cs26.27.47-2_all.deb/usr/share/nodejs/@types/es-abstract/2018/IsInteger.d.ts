import IsInteger = require('../2017/IsInteger');
export = IsInteger;
