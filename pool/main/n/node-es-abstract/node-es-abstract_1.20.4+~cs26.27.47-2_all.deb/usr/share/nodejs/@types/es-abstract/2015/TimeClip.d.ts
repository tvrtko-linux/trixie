import TimeClip = require('../5/TimeClip');
export = TimeClip;
