import ArraySpeciesCreate = require('../2015/ArraySpeciesCreate');
export = ArraySpeciesCreate;
