import HasProperty = require('../2015/HasProperty');
export = HasProperty;
