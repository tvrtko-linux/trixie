import Invoke = require('../2015/Invoke');
export = Invoke;
