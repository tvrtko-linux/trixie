declare function ArrayCreate(length: number, proto?: object | null): unknown[];
export = ArrayCreate;
