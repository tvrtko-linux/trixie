import IsPropertyKey = require('../2017/IsPropertyKey');
export = IsPropertyKey;
