import WeekDay = require('../2016/WeekDay');
export = WeekDay;
