import TimeWithinDay = require('../5/TimeWithinDay');
export = TimeWithinDay;
