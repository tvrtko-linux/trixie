declare function IsStringPrefix(p: string, q: string): boolean;
export = IsStringPrefix;
