import IsDataDescriptor = require('../2018/IsDataDescriptor');
export = IsDataDescriptor;
