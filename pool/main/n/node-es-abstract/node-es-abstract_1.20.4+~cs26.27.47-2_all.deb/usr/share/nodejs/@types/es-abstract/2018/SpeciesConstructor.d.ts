import SpeciesConstructor = require('../2017/SpeciesConstructor');
export = SpeciesConstructor;
