import SpeciesConstructor = require('../2016/SpeciesConstructor');
export = SpeciesConstructor;
