import MakeDay = require('../2016/MakeDay');
export = MakeDay;
