import ToInt8 = require('../2017/ToInt8');
export = ToInt8;
