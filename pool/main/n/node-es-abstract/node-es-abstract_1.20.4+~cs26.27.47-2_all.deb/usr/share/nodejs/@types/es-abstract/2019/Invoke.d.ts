import Invoke = require('../2018/Invoke');
export = Invoke;
