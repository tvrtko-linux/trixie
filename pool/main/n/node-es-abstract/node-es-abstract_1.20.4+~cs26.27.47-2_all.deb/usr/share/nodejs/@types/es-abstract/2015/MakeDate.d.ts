import MakeDate = require('../5/MakeDate');
export = MakeDate;
