import SameValueNonNumber = require('../2017/SameValueNonNumber');
export = SameValueNonNumber;
