import MakeTime = require('../5/MakeTime');
export = MakeTime;
