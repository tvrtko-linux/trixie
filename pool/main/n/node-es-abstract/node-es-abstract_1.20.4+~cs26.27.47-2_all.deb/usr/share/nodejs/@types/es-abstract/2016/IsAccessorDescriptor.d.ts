import IsAccessorDescriptor = require('../2015/IsAccessorDescriptor');
export = IsAccessorDescriptor;
