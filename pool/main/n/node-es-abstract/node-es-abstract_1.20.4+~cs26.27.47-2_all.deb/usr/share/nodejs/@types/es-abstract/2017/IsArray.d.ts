import IsArray = require('../2016/IsArray');
export = IsArray;
