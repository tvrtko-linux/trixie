import thisBooleanValue = require('../2017/thisBooleanValue');
export = thisBooleanValue;
