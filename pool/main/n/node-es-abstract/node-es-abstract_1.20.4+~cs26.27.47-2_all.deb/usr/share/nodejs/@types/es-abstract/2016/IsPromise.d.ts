import IsPromise = require('../2015/IsPromise');
export = IsPromise;
