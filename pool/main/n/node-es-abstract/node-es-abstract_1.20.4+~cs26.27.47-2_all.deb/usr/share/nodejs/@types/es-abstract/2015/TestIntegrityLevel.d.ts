declare function TestIntegrityLevel(O: object, level: 'sealed' | 'frozen'): boolean;
export = TestIntegrityLevel;
