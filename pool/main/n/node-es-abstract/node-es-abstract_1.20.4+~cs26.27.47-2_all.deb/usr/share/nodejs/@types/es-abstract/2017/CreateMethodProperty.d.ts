import CreateMethodProperty = require('../2016/CreateMethodProperty');
export = CreateMethodProperty;
