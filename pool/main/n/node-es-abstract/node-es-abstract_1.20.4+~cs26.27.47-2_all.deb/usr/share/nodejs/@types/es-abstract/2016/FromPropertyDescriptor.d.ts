import FromPropertyDescriptor = require('../2015/FromPropertyDescriptor');
export = FromPropertyDescriptor;
