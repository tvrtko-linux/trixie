import TimeClip = require('../2015/TimeClip');
export = TimeClip;
