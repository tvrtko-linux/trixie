import GetV = require('../2017/GetV');
export = GetV;
