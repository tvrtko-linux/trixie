import Set = require('../2015/Set');
export = Set;
