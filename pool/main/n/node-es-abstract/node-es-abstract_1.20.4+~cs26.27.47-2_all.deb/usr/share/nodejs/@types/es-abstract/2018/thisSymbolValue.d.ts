// tslint:disable-next-line: ban-types
declare function thisSymbolValue(value: symbol | Symbol): symbol;
export = thisSymbolValue;
