import IsCallable = require('../2017/IsCallable');
export = IsCallable;
