import thisBooleanValue = require('../2016/thisBooleanValue');
export = thisBooleanValue;
