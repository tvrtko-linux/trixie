import EnumerableOwnPropertyNames = require('../2018/EnumerableOwnPropertyNames');
export = EnumerableOwnPropertyNames;
