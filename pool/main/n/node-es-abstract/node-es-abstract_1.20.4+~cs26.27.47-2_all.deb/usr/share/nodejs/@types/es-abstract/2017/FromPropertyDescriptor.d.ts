import FromPropertyDescriptor = require('../2016/FromPropertyDescriptor');
export = FromPropertyDescriptor;
