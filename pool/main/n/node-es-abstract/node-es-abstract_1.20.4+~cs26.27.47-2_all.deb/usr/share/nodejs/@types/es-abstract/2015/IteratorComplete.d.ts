declare function IteratorComplete(
    iterResult: IteratorResult<unknown, unknown>,
): iterResult is IteratorReturnResult<unknown>;
export = IteratorComplete;
