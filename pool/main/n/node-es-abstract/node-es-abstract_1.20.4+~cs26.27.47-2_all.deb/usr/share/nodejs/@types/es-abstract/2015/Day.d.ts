import Day = require('../5/Day');
export = Day;
