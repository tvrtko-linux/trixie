import ToInt16 = require('../2015/ToInt16');
export = ToInt16;
