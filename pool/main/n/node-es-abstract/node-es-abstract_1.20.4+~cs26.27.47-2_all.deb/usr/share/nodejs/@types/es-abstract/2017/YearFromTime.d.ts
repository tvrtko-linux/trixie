import YearFromTime = require('../2016/YearFromTime');
export = YearFromTime;
