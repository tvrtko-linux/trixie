import MakeDay = require('../2017/MakeDay');
export = MakeDay;
