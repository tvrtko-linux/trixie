import ToBoolean = require('../2015/ToBoolean');
export = ToBoolean;
