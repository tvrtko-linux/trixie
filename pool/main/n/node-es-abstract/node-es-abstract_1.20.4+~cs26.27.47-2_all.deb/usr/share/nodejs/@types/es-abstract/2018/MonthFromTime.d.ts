import MonthFromTime = require('../2017/MonthFromTime');
export = MonthFromTime;
