import IsCallable = require('../2018/IsCallable');
export = IsCallable;
