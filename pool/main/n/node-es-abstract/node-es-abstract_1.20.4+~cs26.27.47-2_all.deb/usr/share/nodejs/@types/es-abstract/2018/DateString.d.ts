declare function DateString(tv: number): string;
export = DateString;
