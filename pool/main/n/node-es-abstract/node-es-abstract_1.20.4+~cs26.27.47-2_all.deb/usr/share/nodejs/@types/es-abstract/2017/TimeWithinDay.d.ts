import TimeWithinDay = require('../2016/TimeWithinDay');
export = TimeWithinDay;
