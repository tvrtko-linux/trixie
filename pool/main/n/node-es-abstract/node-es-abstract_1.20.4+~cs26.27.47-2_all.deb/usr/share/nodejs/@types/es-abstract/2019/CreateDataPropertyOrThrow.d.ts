import CreateDataPropertyOrThrow = require('../2018/CreateDataPropertyOrThrow');
export = CreateDataPropertyOrThrow;
