import IsArray = require('../2017/IsArray');
export = IsArray;
