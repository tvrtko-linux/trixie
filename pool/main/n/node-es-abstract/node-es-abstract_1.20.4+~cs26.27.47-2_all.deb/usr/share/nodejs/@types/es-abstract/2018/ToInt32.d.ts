import ToInt32 = require('../2017/ToInt32');
export = ToInt32;
