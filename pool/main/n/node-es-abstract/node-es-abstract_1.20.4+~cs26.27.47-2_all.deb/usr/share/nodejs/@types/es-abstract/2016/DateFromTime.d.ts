import DateFromTime = require('../2015/DateFromTime');
export = DateFromTime;
