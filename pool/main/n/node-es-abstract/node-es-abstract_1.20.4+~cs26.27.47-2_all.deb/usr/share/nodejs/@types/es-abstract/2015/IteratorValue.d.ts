declare function IteratorValue<T = never, TReturn = never>(iterResult: IteratorResult<T, TReturn>): T | TReturn;
export = IteratorValue;
