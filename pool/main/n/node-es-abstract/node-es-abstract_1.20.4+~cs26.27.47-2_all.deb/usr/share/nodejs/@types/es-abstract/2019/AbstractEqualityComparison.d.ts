import AbstractEqualityComparison = require('../2018/AbstractEqualityComparison');
export = AbstractEqualityComparison;
