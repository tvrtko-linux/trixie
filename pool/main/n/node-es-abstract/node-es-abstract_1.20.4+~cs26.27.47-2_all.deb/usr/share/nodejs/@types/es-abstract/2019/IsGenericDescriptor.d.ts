import IsGenericDescriptor = require('../2018/IsGenericDescriptor');
export = IsGenericDescriptor;
