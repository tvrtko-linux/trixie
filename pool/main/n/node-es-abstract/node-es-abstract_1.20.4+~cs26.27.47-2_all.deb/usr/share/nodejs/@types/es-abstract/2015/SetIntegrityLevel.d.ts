declare function SetIntegrityLevel(O: object, level: 'sealed' | 'frozen'): boolean;
export = SetIntegrityLevel;
