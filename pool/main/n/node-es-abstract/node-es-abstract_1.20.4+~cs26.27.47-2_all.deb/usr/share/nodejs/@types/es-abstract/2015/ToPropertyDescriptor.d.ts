import ToPropertyDescriptor = require('../5/ToPropertyDescriptor');
export = ToPropertyDescriptor;
