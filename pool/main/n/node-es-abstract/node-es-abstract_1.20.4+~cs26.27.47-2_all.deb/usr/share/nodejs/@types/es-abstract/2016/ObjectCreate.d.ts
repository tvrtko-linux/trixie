import ObjectCreate = require('../2015/ObjectCreate');
export = ObjectCreate;
