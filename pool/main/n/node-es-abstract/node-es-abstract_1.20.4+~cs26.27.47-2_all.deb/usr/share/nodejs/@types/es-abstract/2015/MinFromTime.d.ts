import MinFromTime = require('../5/MinFromTime');
export = MinFromTime;
