import CompletePropertyDescriptor = require('../2016/CompletePropertyDescriptor');
export = CompletePropertyDescriptor;
