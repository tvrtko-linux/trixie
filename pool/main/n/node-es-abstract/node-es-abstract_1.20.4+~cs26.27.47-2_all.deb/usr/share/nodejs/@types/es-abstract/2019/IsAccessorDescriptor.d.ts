import IsAccessorDescriptor = require('../2018/IsAccessorDescriptor');
export = IsAccessorDescriptor;
