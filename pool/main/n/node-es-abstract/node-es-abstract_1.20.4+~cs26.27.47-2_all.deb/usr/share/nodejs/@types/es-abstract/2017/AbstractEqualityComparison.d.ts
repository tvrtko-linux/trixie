import AbstractEqualityComparison = require('../2016/AbstractEqualityComparison');
export = AbstractEqualityComparison;
