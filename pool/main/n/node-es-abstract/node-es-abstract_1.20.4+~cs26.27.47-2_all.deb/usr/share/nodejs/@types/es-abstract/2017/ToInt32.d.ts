import ToInt32 = require('../2016/ToInt32');
export = ToInt32;
