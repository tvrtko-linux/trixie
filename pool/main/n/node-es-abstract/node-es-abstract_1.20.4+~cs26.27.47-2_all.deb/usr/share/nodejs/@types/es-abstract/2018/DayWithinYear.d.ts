import DayWithinYear = require('../2017/DayWithinYear');
export = DayWithinYear;
