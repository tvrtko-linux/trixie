import ToUint8 = require('../2017/ToUint8');
export = ToUint8;
