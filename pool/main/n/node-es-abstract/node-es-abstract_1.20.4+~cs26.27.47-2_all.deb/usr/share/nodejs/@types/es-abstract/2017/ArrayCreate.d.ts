import ArrayCreate = require('../2016/ArrayCreate');
export = ArrayCreate;
