declare function ObjectCreate(proto: object | null, internalSlotsList?: readonly []): object;
export = ObjectCreate;
