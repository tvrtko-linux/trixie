import DayFromYear = require('../2018/DayFromYear');
export = DayFromYear;
