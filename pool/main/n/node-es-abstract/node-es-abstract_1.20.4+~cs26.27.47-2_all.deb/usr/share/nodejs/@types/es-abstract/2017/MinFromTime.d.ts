import MinFromTime = require('../2016/MinFromTime');
export = MinFromTime;
