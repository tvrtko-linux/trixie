import Get = require('../2015/Get');
export = Get;
