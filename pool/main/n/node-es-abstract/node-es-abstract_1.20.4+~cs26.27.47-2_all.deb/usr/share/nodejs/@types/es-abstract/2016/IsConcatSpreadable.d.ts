import IsConcatSpreadable = require('../2015/IsConcatSpreadable');
export = IsConcatSpreadable;
