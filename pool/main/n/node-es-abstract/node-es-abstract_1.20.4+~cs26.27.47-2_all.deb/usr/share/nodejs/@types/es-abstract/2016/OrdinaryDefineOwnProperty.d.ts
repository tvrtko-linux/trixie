import OrdinaryDefineOwnProperty = require('../2015/OrdinaryDefineOwnProperty');
export = OrdinaryDefineOwnProperty;
