import IsExtensible = require('../2015/IsExtensible');
export = IsExtensible;
