import CanonicalNumericIndexString = require('../2016/CanonicalNumericIndexString');
export = CanonicalNumericIndexString;
