// tslint:disable-next-line: ban-types
declare function thisNumberValue(value: number | Number): number;
export = thisNumberValue;
