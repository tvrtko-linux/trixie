import thisNumberValue = require('../2016/thisNumberValue');
export = thisNumberValue;
