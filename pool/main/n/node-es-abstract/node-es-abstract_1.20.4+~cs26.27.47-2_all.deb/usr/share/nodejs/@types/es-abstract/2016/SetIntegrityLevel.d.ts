import SetIntegrityLevel = require('../2015/SetIntegrityLevel');
export = SetIntegrityLevel;
