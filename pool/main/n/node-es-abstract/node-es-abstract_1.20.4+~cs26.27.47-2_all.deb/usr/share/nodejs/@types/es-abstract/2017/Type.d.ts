import Type = require('../2016/Type');
export = Type;
