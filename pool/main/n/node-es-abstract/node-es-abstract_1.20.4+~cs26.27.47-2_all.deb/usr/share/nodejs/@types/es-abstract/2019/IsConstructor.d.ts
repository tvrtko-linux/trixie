import IsConstructor = require('../2018/IsConstructor');
export = IsConstructor;
