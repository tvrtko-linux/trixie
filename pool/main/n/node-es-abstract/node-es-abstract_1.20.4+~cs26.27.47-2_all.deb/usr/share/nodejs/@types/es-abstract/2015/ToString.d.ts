import ToString = require('../5/ToString');
export = ToString;
