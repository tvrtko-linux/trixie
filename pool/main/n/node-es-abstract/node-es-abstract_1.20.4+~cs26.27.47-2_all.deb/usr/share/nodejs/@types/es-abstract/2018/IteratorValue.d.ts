import IteratorValue = require('../2017/IteratorValue');
export = IteratorValue;
