import GetIterator = require('../2018/GetIterator');
export = GetIterator;
