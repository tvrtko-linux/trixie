import CreateListFromArrayLike = require('../2015/CreateListFromArrayLike');
export = CreateListFromArrayLike;
