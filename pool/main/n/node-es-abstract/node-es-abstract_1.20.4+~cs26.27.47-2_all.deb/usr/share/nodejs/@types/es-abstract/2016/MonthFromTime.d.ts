import MonthFromTime = require('../2015/MonthFromTime');
export = MonthFromTime;
