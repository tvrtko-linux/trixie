import thisStringValue = require('../2017/thisStringValue');
export = thisStringValue;
