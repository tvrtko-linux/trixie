import IsAccessorDescriptor = require('../2016/IsAccessorDescriptor');
export = IsAccessorDescriptor;
