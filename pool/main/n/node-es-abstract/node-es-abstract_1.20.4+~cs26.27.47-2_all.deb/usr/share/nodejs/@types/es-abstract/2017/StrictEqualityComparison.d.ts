import StrictEqualityComparison = require('../2016/StrictEqualityComparison');
export = StrictEqualityComparison;
