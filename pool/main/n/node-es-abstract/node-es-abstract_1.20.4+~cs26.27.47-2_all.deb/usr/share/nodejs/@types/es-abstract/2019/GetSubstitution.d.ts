import GetSubstitution = require('../2018/GetSubstitution');
export = GetSubstitution;
