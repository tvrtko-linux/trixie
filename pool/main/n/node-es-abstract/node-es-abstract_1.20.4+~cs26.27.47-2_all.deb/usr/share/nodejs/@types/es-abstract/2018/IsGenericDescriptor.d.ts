import IsGenericDescriptor = require('../2017/IsGenericDescriptor');
export = IsGenericDescriptor;
