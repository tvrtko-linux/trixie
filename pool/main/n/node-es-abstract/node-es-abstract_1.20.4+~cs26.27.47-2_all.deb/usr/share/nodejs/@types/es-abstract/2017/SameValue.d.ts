import SameValue = require('../2016/SameValue');
export = SameValue;
