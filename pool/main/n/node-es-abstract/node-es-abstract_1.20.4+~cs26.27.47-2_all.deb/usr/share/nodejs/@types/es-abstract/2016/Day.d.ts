import Day = require('../2015/Day');
export = Day;
