import SetIntegrityLevel = require('../2016/SetIntegrityLevel');
export = SetIntegrityLevel;
