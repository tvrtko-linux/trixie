import CompletePropertyDescriptor = require('../2018/CompletePropertyDescriptor');
export = CompletePropertyDescriptor;
