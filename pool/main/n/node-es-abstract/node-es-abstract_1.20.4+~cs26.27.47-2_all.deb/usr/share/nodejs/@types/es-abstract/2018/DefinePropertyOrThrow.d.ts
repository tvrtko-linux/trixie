import DefinePropertyOrThrow = require('../2017/DefinePropertyOrThrow');
export = DefinePropertyOrThrow;
