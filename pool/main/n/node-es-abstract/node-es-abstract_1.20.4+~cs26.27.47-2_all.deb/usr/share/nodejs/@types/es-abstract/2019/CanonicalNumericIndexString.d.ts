import CanonicalNumericIndexString = require('../2018/CanonicalNumericIndexString');
export = CanonicalNumericIndexString;
