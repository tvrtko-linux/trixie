import GetMethod = require('../2018/GetMethod');
export = GetMethod;
