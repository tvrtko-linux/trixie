import AdvanceStringIndex = require('../2015/AdvanceStringIndex');
export = AdvanceStringIndex;
