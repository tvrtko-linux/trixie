import IsPropertyDescriptor = require('../2015/IsPropertyDescriptor');
export = IsPropertyDescriptor;
