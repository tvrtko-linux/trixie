import ToInteger = require('../2016/ToInteger');
export = ToInteger;
