import GetPrototypeFromConstructor = require('../2017/GetPrototypeFromConstructor');
export = GetPrototypeFromConstructor;
