import EnumerableOwnPropertyNames = require('../2017/EnumerableOwnProperties');
export = EnumerableOwnPropertyNames;
