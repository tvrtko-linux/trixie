import SymbolDescriptiveString = require('../2015/SymbolDescriptiveString');
export = SymbolDescriptiveString;
