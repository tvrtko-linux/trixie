import DateFromTime = require('../2018/DateFromTime');
export = DateFromTime;
