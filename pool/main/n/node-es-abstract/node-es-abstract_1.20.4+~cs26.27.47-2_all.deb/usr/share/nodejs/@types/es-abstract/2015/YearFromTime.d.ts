import YearFromTime = require('../5/YearFromTime');
export = YearFromTime;
