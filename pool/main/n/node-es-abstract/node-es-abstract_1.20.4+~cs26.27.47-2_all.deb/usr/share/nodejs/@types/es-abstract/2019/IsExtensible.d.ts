import IsExtensible = require('../2018/IsExtensible');
export = IsExtensible;
