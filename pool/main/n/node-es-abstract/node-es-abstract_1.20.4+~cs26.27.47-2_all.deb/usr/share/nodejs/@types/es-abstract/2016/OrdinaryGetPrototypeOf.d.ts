declare function OrdinaryGetPrototypeOf(O: object): object | null;
export = OrdinaryGetPrototypeOf;
