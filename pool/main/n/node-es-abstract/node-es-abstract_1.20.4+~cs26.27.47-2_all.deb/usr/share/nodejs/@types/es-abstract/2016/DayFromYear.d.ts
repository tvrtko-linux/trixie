import DayFromYear = require('../2015/DayFromYear');
export = DayFromYear;
