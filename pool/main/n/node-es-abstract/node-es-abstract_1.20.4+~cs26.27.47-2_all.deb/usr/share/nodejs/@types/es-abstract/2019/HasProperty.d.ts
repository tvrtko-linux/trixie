import HasProperty = require('../2018/HasProperty');
export = HasProperty;
