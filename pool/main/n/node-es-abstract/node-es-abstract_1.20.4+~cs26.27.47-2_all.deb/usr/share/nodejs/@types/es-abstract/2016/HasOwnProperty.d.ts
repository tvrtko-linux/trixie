import HasOwnProperty = require('../2015/HasOwnProperty');
export = HasOwnProperty;
