import DayFromYear = require('../5/DayFromYear');
export = DayFromYear;
