import TestIntegrityLevel = require('../2017/TestIntegrityLevel');
export = TestIntegrityLevel;
