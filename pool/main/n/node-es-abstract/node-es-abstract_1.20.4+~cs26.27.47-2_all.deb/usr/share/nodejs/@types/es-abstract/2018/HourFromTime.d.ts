import HourFromTime = require('../2017/HourFromTime');
export = HourFromTime;
