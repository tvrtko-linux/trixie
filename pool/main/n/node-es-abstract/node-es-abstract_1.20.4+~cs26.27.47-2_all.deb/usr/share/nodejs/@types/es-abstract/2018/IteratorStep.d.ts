import IteratorStep = require('../2017/IteratorStep');
export = IteratorStep;
