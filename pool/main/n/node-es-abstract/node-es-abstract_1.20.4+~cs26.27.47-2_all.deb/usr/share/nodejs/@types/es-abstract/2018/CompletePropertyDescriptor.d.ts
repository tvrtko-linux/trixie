import CompletePropertyDescriptor = require('../2017/CompletePropertyDescriptor');
export = CompletePropertyDescriptor;
