declare function TimeString(tv: number): string;
export = TimeString;
