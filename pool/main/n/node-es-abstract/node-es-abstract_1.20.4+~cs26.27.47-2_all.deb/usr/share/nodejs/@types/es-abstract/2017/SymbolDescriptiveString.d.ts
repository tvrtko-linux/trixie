import SymbolDescriptiveString = require('../2016/SymbolDescriptiveString');
export = SymbolDescriptiveString;
