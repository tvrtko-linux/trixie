import Get = require('../2016/Get');
export = Get;
