import ToLength = require('../2015/ToLength');
export = ToLength;
