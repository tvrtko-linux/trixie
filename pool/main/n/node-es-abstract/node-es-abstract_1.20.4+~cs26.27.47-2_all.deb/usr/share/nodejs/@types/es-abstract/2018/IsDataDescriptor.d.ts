import IsDataDescriptor = require('../2017/IsDataDescriptor');
export = IsDataDescriptor;
