import modulo = require('../2017/modulo');
export = modulo;
