import DaysInYear = require('../2016/DaysInYear');
export = DaysInYear;
