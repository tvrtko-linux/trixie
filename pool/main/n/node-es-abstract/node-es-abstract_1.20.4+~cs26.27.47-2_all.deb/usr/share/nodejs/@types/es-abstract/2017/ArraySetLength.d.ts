import ArraySetLength = require('../2016/ArraySetLength');
export = ArraySetLength;
