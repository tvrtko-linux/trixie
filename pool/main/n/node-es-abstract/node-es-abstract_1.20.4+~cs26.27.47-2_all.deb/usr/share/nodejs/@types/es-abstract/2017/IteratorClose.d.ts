import IteratorClose = require('../2016/IteratorClose');
export = IteratorClose;
