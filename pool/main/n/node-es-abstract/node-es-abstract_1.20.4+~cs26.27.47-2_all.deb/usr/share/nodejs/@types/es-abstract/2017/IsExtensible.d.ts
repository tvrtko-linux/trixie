import IsExtensible = require('../2016/IsExtensible');
export = IsExtensible;
