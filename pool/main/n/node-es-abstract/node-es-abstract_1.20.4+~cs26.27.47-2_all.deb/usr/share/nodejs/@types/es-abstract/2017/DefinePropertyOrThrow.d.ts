import DefinePropertyOrThrow = require('../2016/DefinePropertyOrThrow');
export = DefinePropertyOrThrow;
