import RequireObjectCoercible = require('../2015/RequireObjectCoercible');
export = RequireObjectCoercible;
