import Type = require('../2017/Type');
export = Type;
