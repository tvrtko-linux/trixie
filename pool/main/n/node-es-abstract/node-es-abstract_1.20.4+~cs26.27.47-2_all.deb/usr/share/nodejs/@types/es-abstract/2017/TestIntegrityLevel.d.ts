import TestIntegrityLevel = require('../2016/TestIntegrityLevel');
export = TestIntegrityLevel;
