"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// A temporary value used to identify if the loop should be broken.
// See #1064, #1293
const breakLoop = {};
var _default = breakLoop;
exports.default = _default;
module.exports = exports.default;