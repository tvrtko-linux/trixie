// A temporary value used to identify if the loop should be broken.
// See #1064, #1293
const breakLoop = {};
export default breakLoop;
