"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "all", {
  enumerable: true,
  get: function () {
    return _every.default;
  }
});
Object.defineProperty(exports, "allLimit", {
  enumerable: true,
  get: function () {
    return _everyLimit.default;
  }
});
Object.defineProperty(exports, "allSeries", {
  enumerable: true,
  get: function () {
    return _everySeries.default;
  }
});
Object.defineProperty(exports, "any", {
  enumerable: true,
  get: function () {
    return _some.default;
  }
});
Object.defineProperty(exports, "anyLimit", {
  enumerable: true,
  get: function () {
    return _someLimit.default;
  }
});
Object.defineProperty(exports, "anySeries", {
  enumerable: true,
  get: function () {
    return _someSeries.default;
  }
});
Object.defineProperty(exports, "apply", {
  enumerable: true,
  get: function () {
    return _apply.default;
  }
});
Object.defineProperty(exports, "applyEach", {
  enumerable: true,
  get: function () {
    return _applyEach.default;
  }
});
Object.defineProperty(exports, "applyEachSeries", {
  enumerable: true,
  get: function () {
    return _applyEachSeries.default;
  }
});
Object.defineProperty(exports, "asyncify", {
  enumerable: true,
  get: function () {
    return _asyncify.default;
  }
});
Object.defineProperty(exports, "auto", {
  enumerable: true,
  get: function () {
    return _auto.default;
  }
});
Object.defineProperty(exports, "autoInject", {
  enumerable: true,
  get: function () {
    return _autoInject.default;
  }
});
Object.defineProperty(exports, "cargo", {
  enumerable: true,
  get: function () {
    return _cargo.default;
  }
});
Object.defineProperty(exports, "cargoQueue", {
  enumerable: true,
  get: function () {
    return _cargoQueue.default;
  }
});
Object.defineProperty(exports, "compose", {
  enumerable: true,
  get: function () {
    return _compose.default;
  }
});
Object.defineProperty(exports, "concat", {
  enumerable: true,
  get: function () {
    return _concat.default;
  }
});
Object.defineProperty(exports, "concatLimit", {
  enumerable: true,
  get: function () {
    return _concatLimit.default;
  }
});
Object.defineProperty(exports, "concatSeries", {
  enumerable: true,
  get: function () {
    return _concatSeries.default;
  }
});
Object.defineProperty(exports, "constant", {
  enumerable: true,
  get: function () {
    return _constant.default;
  }
});
exports.default = void 0;
Object.defineProperty(exports, "detect", {
  enumerable: true,
  get: function () {
    return _detect.default;
  }
});
Object.defineProperty(exports, "detectLimit", {
  enumerable: true,
  get: function () {
    return _detectLimit.default;
  }
});
Object.defineProperty(exports, "detectSeries", {
  enumerable: true,
  get: function () {
    return _detectSeries.default;
  }
});
Object.defineProperty(exports, "dir", {
  enumerable: true,
  get: function () {
    return _dir.default;
  }
});
Object.defineProperty(exports, "doDuring", {
  enumerable: true,
  get: function () {
    return _doWhilst.default;
  }
});
Object.defineProperty(exports, "doUntil", {
  enumerable: true,
  get: function () {
    return _doUntil.default;
  }
});
Object.defineProperty(exports, "doWhilst", {
  enumerable: true,
  get: function () {
    return _doWhilst.default;
  }
});
Object.defineProperty(exports, "during", {
  enumerable: true,
  get: function () {
    return _whilst.default;
  }
});
Object.defineProperty(exports, "each", {
  enumerable: true,
  get: function () {
    return _each.default;
  }
});
Object.defineProperty(exports, "eachLimit", {
  enumerable: true,
  get: function () {
    return _eachLimit.default;
  }
});
Object.defineProperty(exports, "eachOf", {
  enumerable: true,
  get: function () {
    return _eachOf.default;
  }
});
Object.defineProperty(exports, "eachOfLimit", {
  enumerable: true,
  get: function () {
    return _eachOfLimit.default;
  }
});
Object.defineProperty(exports, "eachOfSeries", {
  enumerable: true,
  get: function () {
    return _eachOfSeries.default;
  }
});
Object.defineProperty(exports, "eachSeries", {
  enumerable: true,
  get: function () {
    return _eachSeries.default;
  }
});
Object.defineProperty(exports, "ensureAsync", {
  enumerable: true,
  get: function () {
    return _ensureAsync.default;
  }
});
Object.defineProperty(exports, "every", {
  enumerable: true,
  get: function () {
    return _every.default;
  }
});
Object.defineProperty(exports, "everyLimit", {
  enumerable: true,
  get: function () {
    return _everyLimit.default;
  }
});
Object.defineProperty(exports, "everySeries", {
  enumerable: true,
  get: function () {
    return _everySeries.default;
  }
});
Object.defineProperty(exports, "filter", {
  enumerable: true,
  get: function () {
    return _filter.default;
  }
});
Object.defineProperty(exports, "filterLimit", {
  enumerable: true,
  get: function () {
    return _filterLimit.default;
  }
});
Object.defineProperty(exports, "filterSeries", {
  enumerable: true,
  get: function () {
    return _filterSeries.default;
  }
});
Object.defineProperty(exports, "find", {
  enumerable: true,
  get: function () {
    return _detect.default;
  }
});
Object.defineProperty(exports, "findLimit", {
  enumerable: true,
  get: function () {
    return _detectLimit.default;
  }
});
Object.defineProperty(exports, "findSeries", {
  enumerable: true,
  get: function () {
    return _detectSeries.default;
  }
});
Object.defineProperty(exports, "flatMap", {
  enumerable: true,
  get: function () {
    return _concat.default;
  }
});
Object.defineProperty(exports, "flatMapLimit", {
  enumerable: true,
  get: function () {
    return _concatLimit.default;
  }
});
Object.defineProperty(exports, "flatMapSeries", {
  enumerable: true,
  get: function () {
    return _concatSeries.default;
  }
});
Object.defineProperty(exports, "foldl", {
  enumerable: true,
  get: function () {
    return _reduce.default;
  }
});
Object.defineProperty(exports, "foldr", {
  enumerable: true,
  get: function () {
    return _reduceRight.default;
  }
});
Object.defineProperty(exports, "forEach", {
  enumerable: true,
  get: function () {
    return _each.default;
  }
});
Object.defineProperty(exports, "forEachLimit", {
  enumerable: true,
  get: function () {
    return _eachLimit.default;
  }
});
Object.defineProperty(exports, "forEachOf", {
  enumerable: true,
  get: function () {
    return _eachOf.default;
  }
});
Object.defineProperty(exports, "forEachOfLimit", {
  enumerable: true,
  get: function () {
    return _eachOfLimit.default;
  }
});
Object.defineProperty(exports, "forEachOfSeries", {
  enumerable: true,
  get: function () {
    return _eachOfSeries.default;
  }
});
Object.defineProperty(exports, "forEachSeries", {
  enumerable: true,
  get: function () {
    return _eachSeries.default;
  }
});
Object.defineProperty(exports, "forever", {
  enumerable: true,
  get: function () {
    return _forever.default;
  }
});
Object.defineProperty(exports, "groupBy", {
  enumerable: true,
  get: function () {
    return _groupBy.default;
  }
});
Object.defineProperty(exports, "groupByLimit", {
  enumerable: true,
  get: function () {
    return _groupByLimit.default;
  }
});
Object.defineProperty(exports, "groupBySeries", {
  enumerable: true,
  get: function () {
    return _groupBySeries.default;
  }
});
Object.defineProperty(exports, "inject", {
  enumerable: true,
  get: function () {
    return _reduce.default;
  }
});
Object.defineProperty(exports, "log", {
  enumerable: true,
  get: function () {
    return _log.default;
  }
});
Object.defineProperty(exports, "map", {
  enumerable: true,
  get: function () {
    return _map.default;
  }
});
Object.defineProperty(exports, "mapLimit", {
  enumerable: true,
  get: function () {
    return _mapLimit.default;
  }
});
Object.defineProperty(exports, "mapSeries", {
  enumerable: true,
  get: function () {
    return _mapSeries.default;
  }
});
Object.defineProperty(exports, "mapValues", {
  enumerable: true,
  get: function () {
    return _mapValues.default;
  }
});
Object.defineProperty(exports, "mapValuesLimit", {
  enumerable: true,
  get: function () {
    return _mapValuesLimit.default;
  }
});
Object.defineProperty(exports, "mapValuesSeries", {
  enumerable: true,
  get: function () {
    return _mapValuesSeries.default;
  }
});
Object.defineProperty(exports, "memoize", {
  enumerable: true,
  get: function () {
    return _memoize.default;
  }
});
Object.defineProperty(exports, "nextTick", {
  enumerable: true,
  get: function () {
    return _nextTick.default;
  }
});
Object.defineProperty(exports, "parallel", {
  enumerable: true,
  get: function () {
    return _parallel.default;
  }
});
Object.defineProperty(exports, "parallelLimit", {
  enumerable: true,
  get: function () {
    return _parallelLimit.default;
  }
});
Object.defineProperty(exports, "priorityQueue", {
  enumerable: true,
  get: function () {
    return _priorityQueue.default;
  }
});
Object.defineProperty(exports, "queue", {
  enumerable: true,
  get: function () {
    return _queue.default;
  }
});
Object.defineProperty(exports, "race", {
  enumerable: true,
  get: function () {
    return _race.default;
  }
});
Object.defineProperty(exports, "reduce", {
  enumerable: true,
  get: function () {
    return _reduce.default;
  }
});
Object.defineProperty(exports, "reduceRight", {
  enumerable: true,
  get: function () {
    return _reduceRight.default;
  }
});
Object.defineProperty(exports, "reflect", {
  enumerable: true,
  get: function () {
    return _reflect.default;
  }
});
Object.defineProperty(exports, "reflectAll", {
  enumerable: true,
  get: function () {
    return _reflectAll.default;
  }
});
Object.defineProperty(exports, "reject", {
  enumerable: true,
  get: function () {
    return _reject.default;
  }
});
Object.defineProperty(exports, "rejectLimit", {
  enumerable: true,
  get: function () {
    return _rejectLimit.default;
  }
});
Object.defineProperty(exports, "rejectSeries", {
  enumerable: true,
  get: function () {
    return _rejectSeries.default;
  }
});
Object.defineProperty(exports, "retry", {
  enumerable: true,
  get: function () {
    return _retry.default;
  }
});
Object.defineProperty(exports, "retryable", {
  enumerable: true,
  get: function () {
    return _retryable.default;
  }
});
Object.defineProperty(exports, "select", {
  enumerable: true,
  get: function () {
    return _filter.default;
  }
});
Object.defineProperty(exports, "selectLimit", {
  enumerable: true,
  get: function () {
    return _filterLimit.default;
  }
});
Object.defineProperty(exports, "selectSeries", {
  enumerable: true,
  get: function () {
    return _filterSeries.default;
  }
});
Object.defineProperty(exports, "seq", {
  enumerable: true,
  get: function () {
    return _seq.default;
  }
});
Object.defineProperty(exports, "series", {
  enumerable: true,
  get: function () {
    return _series.default;
  }
});
Object.defineProperty(exports, "setImmediate", {
  enumerable: true,
  get: function () {
    return _setImmediate.default;
  }
});
Object.defineProperty(exports, "some", {
  enumerable: true,
  get: function () {
    return _some.default;
  }
});
Object.defineProperty(exports, "someLimit", {
  enumerable: true,
  get: function () {
    return _someLimit.default;
  }
});
Object.defineProperty(exports, "someSeries", {
  enumerable: true,
  get: function () {
    return _someSeries.default;
  }
});
Object.defineProperty(exports, "sortBy", {
  enumerable: true,
  get: function () {
    return _sortBy.default;
  }
});
Object.defineProperty(exports, "timeout", {
  enumerable: true,
  get: function () {
    return _timeout.default;
  }
});
Object.defineProperty(exports, "times", {
  enumerable: true,
  get: function () {
    return _times.default;
  }
});
Object.defineProperty(exports, "timesLimit", {
  enumerable: true,
  get: function () {
    return _timesLimit.default;
  }
});
Object.defineProperty(exports, "timesSeries", {
  enumerable: true,
  get: function () {
    return _timesSeries.default;
  }
});
Object.defineProperty(exports, "transform", {
  enumerable: true,
  get: function () {
    return _transform.default;
  }
});
Object.defineProperty(exports, "tryEach", {
  enumerable: true,
  get: function () {
    return _tryEach.default;
  }
});
Object.defineProperty(exports, "unmemoize", {
  enumerable: true,
  get: function () {
    return _unmemoize.default;
  }
});
Object.defineProperty(exports, "until", {
  enumerable: true,
  get: function () {
    return _until.default;
  }
});
Object.defineProperty(exports, "waterfall", {
  enumerable: true,
  get: function () {
    return _waterfall.default;
  }
});
Object.defineProperty(exports, "whilst", {
  enumerable: true,
  get: function () {
    return _whilst.default;
  }
});
Object.defineProperty(exports, "wrapSync", {
  enumerable: true,
  get: function () {
    return _asyncify.default;
  }
});
var _apply = _interopRequireDefault(require("./apply"));
var _applyEach = _interopRequireDefault(require("./applyEach"));
var _applyEachSeries = _interopRequireDefault(require("./applyEachSeries"));
var _asyncify = _interopRequireDefault(require("./asyncify"));
var _auto = _interopRequireDefault(require("./auto"));
var _autoInject = _interopRequireDefault(require("./autoInject"));
var _cargo = _interopRequireDefault(require("./cargo"));
var _cargoQueue = _interopRequireDefault(require("./cargoQueue"));
var _compose = _interopRequireDefault(require("./compose"));
var _concat = _interopRequireDefault(require("./concat"));
var _concatLimit = _interopRequireDefault(require("./concatLimit"));
var _concatSeries = _interopRequireDefault(require("./concatSeries"));
var _constant = _interopRequireDefault(require("./constant"));
var _detect = _interopRequireDefault(require("./detect"));
var _detectLimit = _interopRequireDefault(require("./detectLimit"));
var _detectSeries = _interopRequireDefault(require("./detectSeries"));
var _dir = _interopRequireDefault(require("./dir"));
var _doUntil = _interopRequireDefault(require("./doUntil"));
var _doWhilst = _interopRequireDefault(require("./doWhilst"));
var _each = _interopRequireDefault(require("./each"));
var _eachLimit = _interopRequireDefault(require("./eachLimit"));
var _eachOf = _interopRequireDefault(require("./eachOf"));
var _eachOfLimit = _interopRequireDefault(require("./eachOfLimit"));
var _eachOfSeries = _interopRequireDefault(require("./eachOfSeries"));
var _eachSeries = _interopRequireDefault(require("./eachSeries"));
var _ensureAsync = _interopRequireDefault(require("./ensureAsync"));
var _every = _interopRequireDefault(require("./every"));
var _everyLimit = _interopRequireDefault(require("./everyLimit"));
var _everySeries = _interopRequireDefault(require("./everySeries"));
var _filter = _interopRequireDefault(require("./filter"));
var _filterLimit = _interopRequireDefault(require("./filterLimit"));
var _filterSeries = _interopRequireDefault(require("./filterSeries"));
var _forever = _interopRequireDefault(require("./forever"));
var _groupBy = _interopRequireDefault(require("./groupBy"));
var _groupByLimit = _interopRequireDefault(require("./groupByLimit"));
var _groupBySeries = _interopRequireDefault(require("./groupBySeries"));
var _log = _interopRequireDefault(require("./log"));
var _map = _interopRequireDefault(require("./map"));
var _mapLimit = _interopRequireDefault(require("./mapLimit"));
var _mapSeries = _interopRequireDefault(require("./mapSeries"));
var _mapValues = _interopRequireDefault(require("./mapValues"));
var _mapValuesLimit = _interopRequireDefault(require("./mapValuesLimit"));
var _mapValuesSeries = _interopRequireDefault(require("./mapValuesSeries"));
var _memoize = _interopRequireDefault(require("./memoize"));
var _nextTick = _interopRequireDefault(require("./nextTick"));
var _parallel = _interopRequireDefault(require("./parallel"));
var _parallelLimit = _interopRequireDefault(require("./parallelLimit"));
var _priorityQueue = _interopRequireDefault(require("./priorityQueue"));
var _queue = _interopRequireDefault(require("./queue"));
var _race = _interopRequireDefault(require("./race"));
var _reduce = _interopRequireDefault(require("./reduce"));
var _reduceRight = _interopRequireDefault(require("./reduceRight"));
var _reflect = _interopRequireDefault(require("./reflect"));
var _reflectAll = _interopRequireDefault(require("./reflectAll"));
var _reject = _interopRequireDefault(require("./reject"));
var _rejectLimit = _interopRequireDefault(require("./rejectLimit"));
var _rejectSeries = _interopRequireDefault(require("./rejectSeries"));
var _retry = _interopRequireDefault(require("./retry"));
var _retryable = _interopRequireDefault(require("./retryable"));
var _seq = _interopRequireDefault(require("./seq"));
var _series = _interopRequireDefault(require("./series"));
var _setImmediate = _interopRequireDefault(require("./setImmediate"));
var _some = _interopRequireDefault(require("./some"));
var _someLimit = _interopRequireDefault(require("./someLimit"));
var _someSeries = _interopRequireDefault(require("./someSeries"));
var _sortBy = _interopRequireDefault(require("./sortBy"));
var _timeout = _interopRequireDefault(require("./timeout"));
var _times = _interopRequireDefault(require("./times"));
var _timesLimit = _interopRequireDefault(require("./timesLimit"));
var _timesSeries = _interopRequireDefault(require("./timesSeries"));
var _transform = _interopRequireDefault(require("./transform"));
var _tryEach = _interopRequireDefault(require("./tryEach"));
var _unmemoize = _interopRequireDefault(require("./unmemoize"));
var _until = _interopRequireDefault(require("./until"));
var _waterfall = _interopRequireDefault(require("./waterfall"));
var _whilst = _interopRequireDefault(require("./whilst"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
/**
 * An "async function" in the context of Async is an asynchronous function with
 * a variable number of parameters, with the final parameter being a callback.
 * (`function (arg1, arg2, ..., callback) {}`)
 * The final callback is of the form `callback(err, results...)`, which must be
 * called once the function is completed.  The callback should be called with a
 * Error as its first argument to signal that an error occurred.
 * Otherwise, if no error occurred, it should be called with `null` as the first
 * argument, and any additional `result` arguments that may apply, to signal
 * successful completion.
 * The callback must be called exactly once, ideally on a later tick of the
 * JavaScript event loop.
 *
 * This type of function is also referred to as a "Node-style async function",
 * or a "continuation passing-style function" (CPS). Most of the methods of this
 * library are themselves CPS/Node-style async functions, or functions that
 * return CPS/Node-style async functions.
 *
 * Wherever we accept a Node-style async function, we also directly accept an
 * [ES2017 `async` function]{@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/async_function}.
 * In this case, the `async` function will not be passed a final callback
 * argument, and any thrown error will be used as the `err` argument of the
 * implicit callback, and the return value will be used as the `result` value.
 * (i.e. a `rejected` of the returned Promise becomes the `err` callback
 * argument, and a `resolved` value becomes the `result`.)
 *
 * Note, due to JavaScript limitations, we can only detect native `async`
 * functions and not transpilied implementations.
 * Your environment must have `async`/`await` support for this to work.
 * (e.g. Node > v7.6, or a recent version of a modern browser).
 * If you are using `async` functions through a transpiler (e.g. Babel), you
 * must still wrap the function with [asyncify]{@link module:Utils.asyncify},
 * because the `async function` will be compiled to an ordinary function that
 * returns a promise.
 *
 * @typedef {Function} AsyncFunction
 * @static
 */
/**
 * Async is a utility module which provides straight-forward, powerful functions
 * for working with asynchronous JavaScript. Although originally designed for
 * use with [Node.js](http://nodejs.org) and installable via
 * `npm install --save async`, it can also be used directly in the browser.
 * @module async
 * @see AsyncFunction
 */
/**
 * A collection of `async` functions for manipulating collections, such as
 * arrays and objects.
 * @module Collections
 */
/**
 * A collection of `async` functions for controlling the flow through a script.
 * @module ControlFlow
 */
/**
 * A collection of `async` utility functions.
 * @module Utils
 */
var _default = {
  apply: _apply.default,
  applyEach: _applyEach.default,
  applyEachSeries: _applyEachSeries.default,
  asyncify: _asyncify.default,
  auto: _auto.default,
  autoInject: _autoInject.default,
  cargo: _cargo.default,
  cargoQueue: _cargoQueue.default,
  compose: _compose.default,
  concat: _concat.default,
  concatLimit: _concatLimit.default,
  concatSeries: _concatSeries.default,
  constant: _constant.default,
  detect: _detect.default,
  detectLimit: _detectLimit.default,
  detectSeries: _detectSeries.default,
  dir: _dir.default,
  doUntil: _doUntil.default,
  doWhilst: _doWhilst.default,
  each: _each.default,
  eachLimit: _eachLimit.default,
  eachOf: _eachOf.default,
  eachOfLimit: _eachOfLimit.default,
  eachOfSeries: _eachOfSeries.default,
  eachSeries: _eachSeries.default,
  ensureAsync: _ensureAsync.default,
  every: _every.default,
  everyLimit: _everyLimit.default,
  everySeries: _everySeries.default,
  filter: _filter.default,
  filterLimit: _filterLimit.default,
  filterSeries: _filterSeries.default,
  forever: _forever.default,
  groupBy: _groupBy.default,
  groupByLimit: _groupByLimit.default,
  groupBySeries: _groupBySeries.default,
  log: _log.default,
  map: _map.default,
  mapLimit: _mapLimit.default,
  mapSeries: _mapSeries.default,
  mapValues: _mapValues.default,
  mapValuesLimit: _mapValuesLimit.default,
  mapValuesSeries: _mapValuesSeries.default,
  memoize: _memoize.default,
  nextTick: _nextTick.default,
  parallel: _parallel.default,
  parallelLimit: _parallelLimit.default,
  priorityQueue: _priorityQueue.default,
  queue: _queue.default,
  race: _race.default,
  reduce: _reduce.default,
  reduceRight: _reduceRight.default,
  reflect: _reflect.default,
  reflectAll: _reflectAll.default,
  reject: _reject.default,
  rejectLimit: _rejectLimit.default,
  rejectSeries: _rejectSeries.default,
  retry: _retry.default,
  retryable: _retryable.default,
  seq: _seq.default,
  series: _series.default,
  setImmediate: _setImmediate.default,
  some: _some.default,
  someLimit: _someLimit.default,
  someSeries: _someSeries.default,
  sortBy: _sortBy.default,
  timeout: _timeout.default,
  times: _times.default,
  timesLimit: _timesLimit.default,
  timesSeries: _timesSeries.default,
  transform: _transform.default,
  tryEach: _tryEach.default,
  unmemoize: _unmemoize.default,
  until: _until.default,
  waterfall: _waterfall.default,
  whilst: _whilst.default,
  // aliases
  all: _every.default,
  allLimit: _everyLimit.default,
  allSeries: _everySeries.default,
  any: _some.default,
  anyLimit: _someLimit.default,
  anySeries: _someSeries.default,
  find: _detect.default,
  findLimit: _detectLimit.default,
  findSeries: _detectSeries.default,
  flatMap: _concat.default,
  flatMapLimit: _concatLimit.default,
  flatMapSeries: _concatSeries.default,
  forEach: _each.default,
  forEachSeries: _eachSeries.default,
  forEachLimit: _eachLimit.default,
  forEachOf: _eachOf.default,
  forEachOfSeries: _eachOfSeries.default,
  forEachOfLimit: _eachOfLimit.default,
  inject: _reduce.default,
  foldl: _reduce.default,
  foldr: _reduceRight.default,
  select: _filter.default,
  selectLimit: _filterLimit.default,
  selectSeries: _filterSeries.default,
  wrapSync: _asyncify.default,
  during: _whilst.default,
  doDuring: _doWhilst.default
};
exports.default = _default;