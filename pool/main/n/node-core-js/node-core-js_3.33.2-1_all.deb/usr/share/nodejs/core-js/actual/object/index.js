'use strict';
var parent = require('../../stable/object');
require('../../modules/esnext.object.group-by');

module.exports = parent;
