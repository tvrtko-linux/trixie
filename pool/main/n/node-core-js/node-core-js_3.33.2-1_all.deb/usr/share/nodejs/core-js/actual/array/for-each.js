'use strict';
var parent = require('../../stable/array/for-each');

module.exports = parent;
