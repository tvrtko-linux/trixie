'use strict';
var parent = require('../../stable/math');
require('../../modules/esnext.math.f16round');

module.exports = parent;
