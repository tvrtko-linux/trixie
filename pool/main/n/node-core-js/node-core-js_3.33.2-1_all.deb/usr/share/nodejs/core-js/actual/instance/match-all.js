'use strict';
var parent = require('../../stable/instance/match-all');

module.exports = parent;
