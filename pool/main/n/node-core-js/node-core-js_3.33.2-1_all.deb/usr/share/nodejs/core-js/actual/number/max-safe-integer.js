'use strict';
var parent = require('../../stable/number/max-safe-integer');

module.exports = parent;
