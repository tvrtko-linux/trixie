'use strict';
var parent = require('../../stable/typed-array/to-reversed');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.typed-array.to-reversed');

module.exports = parent;
