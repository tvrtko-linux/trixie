'use strict';
require('../stable');
require('../stage/3');

module.exports = require('../internals/path');
