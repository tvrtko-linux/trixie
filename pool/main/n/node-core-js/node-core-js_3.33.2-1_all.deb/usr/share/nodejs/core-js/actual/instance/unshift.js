'use strict';
var parent = require('../../stable/instance/unshift');

module.exports = parent;
