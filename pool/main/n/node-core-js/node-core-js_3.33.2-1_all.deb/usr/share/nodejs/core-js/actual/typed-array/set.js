'use strict';
var parent = require('../../stable/typed-array/set');

module.exports = parent;
