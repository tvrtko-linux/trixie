'use strict';
var parent = require('../../stable/array-buffer');
require('../../modules/esnext.array-buffer.detached');
require('../../modules/esnext.array-buffer.transfer');
require('../../modules/esnext.array-buffer.transfer-to-fixed-length');

module.exports = parent;
