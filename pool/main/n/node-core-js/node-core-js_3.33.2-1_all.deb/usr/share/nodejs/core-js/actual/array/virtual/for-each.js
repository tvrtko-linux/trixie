'use strict';
var parent = require('../../../stable/array/virtual/for-each');

module.exports = parent;
