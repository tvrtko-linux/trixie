'use strict';
var parent = require('../stable/self');

module.exports = parent;
