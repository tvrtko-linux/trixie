'use strict';
var parent = require('../../stable/number/parse-float');

module.exports = parent;
