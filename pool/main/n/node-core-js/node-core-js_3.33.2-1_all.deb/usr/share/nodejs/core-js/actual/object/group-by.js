'use strict';
require('../../modules/es.object.create');
require('../../modules/esnext.object.group-by');

var path = require('../../internals/path');

module.exports = path.Object.groupBy;
