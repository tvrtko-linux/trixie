'use strict';
var parent = require('../../stable/string/replace-all');

module.exports = parent;
