'use strict';
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.string.is-well-formed');

var parent = require('../../../stable/string/virtual/is-well-formed');

module.exports = parent;
