'use strict';
var parent = require('../../stable/typed-array/int32-array');
require('../../actual/typed-array/methods');

module.exports = parent;
