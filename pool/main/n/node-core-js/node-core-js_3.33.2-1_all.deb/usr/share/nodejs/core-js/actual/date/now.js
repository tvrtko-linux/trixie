'use strict';
var parent = require('../../stable/date/now');

module.exports = parent;
