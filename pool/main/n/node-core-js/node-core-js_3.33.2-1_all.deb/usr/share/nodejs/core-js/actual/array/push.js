'use strict';
var parent = require('../../stable/array/push');

module.exports = parent;
