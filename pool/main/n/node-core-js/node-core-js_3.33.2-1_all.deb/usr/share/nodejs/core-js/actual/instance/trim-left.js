'use strict';
var parent = require('../../stable/instance/trim-left');

module.exports = parent;
