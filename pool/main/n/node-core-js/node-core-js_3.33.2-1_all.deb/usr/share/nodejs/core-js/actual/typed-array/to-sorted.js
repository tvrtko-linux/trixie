'use strict';
var parent = require('../../stable/typed-array/to-sorted');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.typed-array.to-sorted');

module.exports = parent;
