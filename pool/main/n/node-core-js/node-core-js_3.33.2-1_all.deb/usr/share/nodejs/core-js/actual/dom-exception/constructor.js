'use strict';
var parent = require('../../stable/dom-exception/constructor');

module.exports = parent;
