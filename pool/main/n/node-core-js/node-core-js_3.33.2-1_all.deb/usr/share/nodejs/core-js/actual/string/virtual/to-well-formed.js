'use strict';
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.string.to-well-formed');

var parent = require('../../../stable/string/virtual/to-well-formed');

module.exports = parent;
