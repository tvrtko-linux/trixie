'use strict';
var parent = require('../../stable/symbol/search');

module.exports = parent;
