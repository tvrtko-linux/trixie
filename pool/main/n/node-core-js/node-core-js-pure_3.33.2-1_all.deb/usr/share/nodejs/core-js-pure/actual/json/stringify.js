'use strict';
var parent = require('../../stable/json/stringify');

module.exports = parent;
