'use strict';
var parent = require('../../stable/instance/find-index');

module.exports = parent;
