'use strict';
var parent = require('../../stable/instance/includes');

module.exports = parent;
