'use strict';
var parent = require('../../stable/object/create');

module.exports = parent;
