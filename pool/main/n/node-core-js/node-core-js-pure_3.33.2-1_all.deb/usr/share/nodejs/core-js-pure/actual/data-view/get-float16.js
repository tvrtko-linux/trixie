'use strict';
require('../../modules/esnext.data-view.get-float16');
