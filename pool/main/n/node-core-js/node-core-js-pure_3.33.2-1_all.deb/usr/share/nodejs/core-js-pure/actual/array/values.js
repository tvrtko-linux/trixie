'use strict';
var parent = require('../../stable/array/values');

module.exports = parent;
