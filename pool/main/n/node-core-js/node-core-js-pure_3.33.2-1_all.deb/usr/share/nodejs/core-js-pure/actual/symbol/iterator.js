'use strict';
var parent = require('../../stable/symbol/iterator');

module.exports = parent;
