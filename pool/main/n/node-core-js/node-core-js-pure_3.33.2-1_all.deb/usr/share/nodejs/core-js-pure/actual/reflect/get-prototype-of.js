'use strict';
var parent = require('../../stable/reflect/get-prototype-of');

module.exports = parent;
