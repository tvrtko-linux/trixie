'use strict';
var parent = require('../../stable/reflect/has');

module.exports = parent;
