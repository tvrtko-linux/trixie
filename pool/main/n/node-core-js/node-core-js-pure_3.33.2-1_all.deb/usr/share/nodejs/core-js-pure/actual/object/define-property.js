'use strict';
var parent = require('../../stable/object/define-property');

module.exports = parent;
