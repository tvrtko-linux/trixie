'use strict';
var parent = require('../stable/parse-float');

module.exports = parent;
