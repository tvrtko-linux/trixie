'use strict';
var parent = require('../../stable/array-buffer/slice');

module.exports = parent;
