'use strict';
var parent = require('../../stable/promise/any');

module.exports = parent;
