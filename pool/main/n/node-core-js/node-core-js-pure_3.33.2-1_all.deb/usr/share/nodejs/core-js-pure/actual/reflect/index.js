'use strict';
var parent = require('../../stable/reflect');

module.exports = parent;
