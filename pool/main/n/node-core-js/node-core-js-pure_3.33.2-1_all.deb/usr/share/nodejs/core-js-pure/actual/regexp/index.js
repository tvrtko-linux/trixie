'use strict';
var parent = require('../../stable/regexp');

module.exports = parent;
