'use strict';
var parent = require('../../stable/object/keys');

module.exports = parent;
