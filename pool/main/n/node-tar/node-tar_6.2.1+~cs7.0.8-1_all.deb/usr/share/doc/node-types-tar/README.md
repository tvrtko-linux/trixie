# Installation
> `npm install --save @types/tar`

# Summary
This package contains type definitions for tar (https://github.com/npm/node-tar).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tar.

### Additional Details
 * Last updated: Fri, 02 Jul 2021 21:32:11 GMT
 * Dependencies: [@types/minipass](https://npmjs.com/package/@types/minipass), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Maxime LUCE](https://github.com/SomaticIT), and [Connor Peet](https://github.com/connor4312).
