const { mkdirp } = require('mkdirp')

module.exports = mkdirp
