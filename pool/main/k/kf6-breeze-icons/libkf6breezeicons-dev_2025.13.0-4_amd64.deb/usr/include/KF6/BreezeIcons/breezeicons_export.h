
#ifndef BREEZEICONS_EXPORT_H
#define BREEZEICONS_EXPORT_H

#ifdef BREEZEICONS_STATIC_DEFINE
#  define BREEZEICONS_EXPORT
#  define BREEZEICONS_NO_EXPORT
#else
#  ifndef BREEZEICONS_EXPORT
#    ifdef KF6BreezeIcons_EXPORTS
        /* We are building this library */
#      define BREEZEICONS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define BREEZEICONS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef BREEZEICONS_NO_EXPORT
#    define BREEZEICONS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef BREEZEICONS_DEPRECATED
#  define BREEZEICONS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef BREEZEICONS_DEPRECATED_EXPORT
#  define BREEZEICONS_DEPRECATED_EXPORT BREEZEICONS_EXPORT BREEZEICONS_DEPRECATED
#endif

#ifndef BREEZEICONS_DEPRECATED_NO_EXPORT
#  define BREEZEICONS_DEPRECATED_NO_EXPORT BREEZEICONS_NO_EXPORT BREEZEICONS_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef BREEZEICONS_NO_DEPRECATED
#    define BREEZEICONS_NO_DEPRECATED
#  endif
#endif

#endif /* BREEZEICONS_EXPORT_H */
