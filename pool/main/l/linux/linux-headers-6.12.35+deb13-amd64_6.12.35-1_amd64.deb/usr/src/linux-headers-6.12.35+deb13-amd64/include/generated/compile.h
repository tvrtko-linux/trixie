#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"debian-kernel"
#define LINUX_COMPILE_HOST	"lists.debian.org"
#define LINUX_COMPILER		"x86_64-linux-gnu-gcc-14 (Debian 14.2.0-19) 14.2.0, GNU ld (GNU Binutils for Debian) 2.44"
