# How to build

These blobs were exported with Matlab/Octave script sof_example_drc.m
from [SOF](https://github.com/thesofproject/sof)

Usage:
cd src/audio/drc/tune; octave --no-window-system sof_example_drc.m
