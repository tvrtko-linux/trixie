# How to build

These blobs were exported with Matlab/Octave scripts from
[SOF](https://github.com/thesofproject/sof)

Usage:
cd src/audio/tdfb/tune; sof_example_all.sh
