/**
 * @fileoverview Index file to allow YAML file to be loaded
 * @author Teddy Katz
 */
"use strict";

module.exports = {
    extends: ["./default.yml"]
};
