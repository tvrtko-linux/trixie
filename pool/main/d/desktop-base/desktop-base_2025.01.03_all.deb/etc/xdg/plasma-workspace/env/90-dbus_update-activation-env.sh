#needed for gtk3 applications to save settings properly
dbus-update-activation-environment --systemd XDG_CONFIG_HOME
