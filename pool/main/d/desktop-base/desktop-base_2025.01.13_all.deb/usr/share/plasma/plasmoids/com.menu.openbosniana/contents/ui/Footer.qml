pragma ComponentBehavior: Bound

import org.kde.plasma.components 3.0 as PC3
import org.kde.plasma.private.kicker 0.1 as Kicker
import org.kde.coreaddons 1.0 as KCoreAddons
import org.kde.kquickcontrolsaddons 2.0
import org.kde.plasma.private.quicklaunch 1.0
import QtQuick.Controls 2.15
import org.kde.plasma.extras as PlasmaExtras
import org.kde.ksvg 1.0 as KSvg
import org.kde.plasma.plasma5support 2.0 as P5Support
import Qt5Compat.GraphicalEffects
import QtQuick
import QtQuick.Layouts 1.1
import QtQml 2.15
import org.kde.kirigami 2.0  as Kirigami
import org.kde.kirigamiaddons.components as KirigamiComponents
import org.kde.plasma.plasmoid 2.0
import org.kde.kcmutils as KCM
import org.kde.plasma.private.sessions as Sessions

PlasmaExtras.PlasmoidHeading {
    id: root
    property real preferredTabBarWidth: 0

    contentWidth: tabBar.implicitWidth + spacing
    contentHeight: leaveButtons.implicitHeight

    // We use an increased vertical padding to improve touch usability
    leftPadding: kickoff.backgroundMetrics.leftPadding
    rightPadding: kickoff.backgroundMetrics.rightPadding
    topPadding: Kirigami.Units.smallSpacing * 2
    bottomPadding: Kirigami.Units.smallSpacing

    topInset: 0
    leftInset: 0
    rightInset: 0
    bottomInset: 0

    spacing: kickoff.backgroundMetrics.spacing
    position: PC3.ToolBar.Footer
    Sessions.SessionManagement
    {
        id: cmd_desk
    }
    KCoreAddons.KUser {
        id: kuser
    }
    //cmd commands
    P5Support.DataSource
    {   id: executable
        engine: "executable"
        connectedSources: []
        onNewData: {
            var exitCode = data["exit code"]
            var exitStatus = data["exit status"]
            var stdout = data["stdout"]
            var stderr = data["stderr"]
            exited(sourceName, exitCode, exitStatus, stdout, stderr)
            disconnectSource(sourceName)
        }
        function exec(cmd) {
            if (cmd) {
                connectSource(cmd)
            }
        }
        signal exited(string cmd, int exitCode, int exitStatus, string stdout, string stderr)
    }
    RowLayout {
        anchors.fill: parent
        spacing: Kirigami.Units.smallSpacing

        // --- Lijeva strana (user avatar + ime) ---
        RowLayout {
            Layout.alignment: Qt.AlignLeft | Qt.AlignVCenter
            spacing: 6

            KirigamiComponents.AvatarButton {
                id: avatar
                Layout.leftMargin: 5
                Layout.minimumWidth: height - 5
                Layout.maximumWidth: height - 5

                text: kuser.loginName
                name: kuser.fullName
                cache: false
                source: kuser.faceIconUrl
                onClicked: KCM.KCMLauncher.openSystemSettings("kcm_users")
            }

            MouseArea {
                id: nameAndInfoMouseArea
                anchors.verticalCenter: parent.verticalCenter
                onClicked: KCM.KCMLauncher.openSystemSettings("kcm_users")

                Kirigami.Heading {
                    id: nameLabel
                    height: parent.height
                    opacity: parent.containsMouse ? 0 : 1
                    color: Kirigami.Theme.textColor
                    level: 4
                    text: kuser.fullName
                    textFormat: Text.PlainText
                    elide: Text.ElideRight
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }

        // --- Prazan razmak koji gura sredinu ---
        Item { Layout.fillWidth: true }

        // --- Sredina (pokretači) ---
        RowLayout {
            Layout.alignment: Qt.AlignHCenter | Qt.AlignVCenter
            spacing: 4
            PC3.ToolButton
            {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/usrhome.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                visible:  true
                onClicked: executable.exec(homeCMD);
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("User Home")
            }
            PC3.ToolButton
            {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/dwn.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                visible:  true
                //onClicked: executable.exec(("dolphin ")+ dwnCMD);
                onClicked: executable.exec(dwnCMD);
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("Downloads")
            }
            PC3.ToolButton
            {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/mus.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                visible:  true
                //onClicked: executable.exec(("dolphin ")+ dwnCMD);
                onClicked: executable.exec(musCMD);
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("Music")
            }
            PC3.ToolButton
            {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/pic.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                visible:  true
                //onClicked: executable.exec(("dolphin ")+ dwnCMD);
                onClicked: executable.exec(picCMD);
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("Pictures")
            }

            PC3.ToolButton
            {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/vid.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                visible:  true
                //onClicked: executable.exec(("dolphin ")+ dwnCMD);
                onClicked: executable.exec(vidCMD);
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("Video")
            }
            PC3.ToolButton
            {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/sysr.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                visible:  true
                onClicked: executable.exec(systemPreferencesCMD);
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("System Preferences")
            }
            PC3.ToolButton
            {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/inf.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                visible:  true
                onClicked: executable.exec(aboutThisComputerCMD);
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("Info")
            }
        }

        // --- Prazan razmak da desni dio ide udesno ---
        Item { Layout.fillWidth: true }

        // --- Desna strana (2 dugmeta) ---
        RowLayout {
            Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
            spacing: 4

            PC3.ToolButton {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/logout.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                Layout.rightMargin: 2
                onClicked: cmd_desk.lock()
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("Lock Screen")
            }
            PC3.ToolButton {
                icon.name: "file:///usr/share/plasma/plasmoids/com.menu.openbosniana/contents/ui/asset/system-shutdown-panel-restart.svg"
                icon.width: Kirigami.Units.iconSizes.medium - 2
                icon.height: Kirigami.Units.iconSizes.medium - 2
                onClicked: cmd_desk.requestLogoutPrompt()
                ToolTip.delay: 200
                ToolTip.timeout: 1000
                ToolTip.visible: hovered
                ToolTip.text: i18n("Leave ...")
            }
        }
    }
}
