function prompt {
  Write-Host "|->[" -NoNewLine -ForegroundColor DarkRed
  Write-Host "$(hostname)" -NoNewLine -ForegroundColor Blue
  Write-Host "@" -NoNewLine -ForegroundColor DarkRed
  Write-Host "$([environment]::username)" -NoNewLine -ForegroundColor Blue
  Write-Host "]-[" -NoNewLine -ForegroundColor DarkRed
  Write-Host "$(Get-Date -Format HH:mm-dd/MM)" -NoNewLine -ForegroundColor Blue
  Write-Host "]-[" -NoNewLine -ForegroundColor DarkRed
  Write-Host "$(Get-Location)" -NoNewLine -ForegroundColor Blue
  Write-Host "]`n|->" -NoNewLine -ForegroundColor DarkRed
  Write-Host "$" -NoNewLine -ForegroundColor Blue
  return " "
}

Write-Output "Welcome to OpenBosniana OS `n"
