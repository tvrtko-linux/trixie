#!/usr/bin/python3

print("OpenBosniana GNU/Linux")
