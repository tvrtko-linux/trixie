#!/usr/bin/perl6

say "OpenBosniana GNU/Linux";
