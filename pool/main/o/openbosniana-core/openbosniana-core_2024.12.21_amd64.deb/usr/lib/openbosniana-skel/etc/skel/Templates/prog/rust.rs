fn main() {
    println!("OpenBosniana GNU/Linux");
}
