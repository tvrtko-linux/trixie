#include <iostream>

using namespace std;

main()
{
	cout << "OpenBosniana GNU/Linux" << endl;
	return 0;
}
