#!/bin/bash

echo "OpenBosniana GNU/Linux"
