#!/usr/bin/perl

print("OpenBosniana GNU/Linux");
