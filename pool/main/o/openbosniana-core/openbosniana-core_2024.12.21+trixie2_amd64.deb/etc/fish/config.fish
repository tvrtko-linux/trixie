function fish_greeting
    echo "Welcome to OpenBosniana OS"
end

function fish_prompt
    echo (set_color red)"|->["(set_color blue)"$hostname"(set_color red)"]─["(set_color blue)(date "+%H:%M-%d/%m")(set_color red)"]─["(set_color blue)"$PWD"(set_color red)"]"
    echo (set_color red)"|->"(set_color blue)"$USER"(set_color red)(set_color blue)"\$"(set_color normal)
end

set PATH ~/.local/bin /snap/bin /usr/sandbox/ /usr/local/bin /usr/bin /bin /usr/local/games /usr/games /usr/share/games /usr/local/sbin /usr/sbin /sbin $PATH

alias ls='ls -lh --color=auto'
alias dir='dir --color=auto'
alias vdir='vdir --color=auto'
alias grep='grep --color=auto'
alias fgrep='fgrep --color=auto'
alias egrep='egrep --color=auto'
# some more ls aliases
alias ll='ls -lh'
alias la='ls -lha'
alias l='ls -CF'
alias em='emacs -nw'
alias dd='dd status=progress'
alias _='sudo'
alias _i='sudo -i'
alias fucking='sudo'
alias please='sudo'

