public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("OpenBosniana GNU/Linux");
    }
}
