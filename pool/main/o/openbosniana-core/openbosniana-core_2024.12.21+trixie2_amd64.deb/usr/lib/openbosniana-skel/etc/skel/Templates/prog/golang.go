package main
import "fmt"
func main() {
    fmt.Println("OpenBosniana GNU/Linux")
}

