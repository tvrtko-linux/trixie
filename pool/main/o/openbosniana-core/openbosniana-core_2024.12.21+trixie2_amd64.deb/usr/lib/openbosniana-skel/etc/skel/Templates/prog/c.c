#include <stdio.h>

int main(int argc, char **argv)
{
	printf("OpenBosniana GNU/Linux\n");
	return 0;
}
