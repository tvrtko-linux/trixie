    document.addEventListener("contextmenu", function(e) {
      e.preventDefault();
    });
    document.addEventListener("selectstart", function(e) {
      e.preventDefault();
    });
    document.addEventListener("copy", function(e) {
      e.preventDefault();
    });
    document.addEventListener("dragstart", function(e) {
      e.preventDefault();
    });
