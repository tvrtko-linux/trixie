// PowerBar.qml
import QtQuick 2.15

Row {
    id: powerBarRoot
    spacing: 20
    height: 32
	property Item passwordField
    property color iconColor: "white"
	property Item root
    // Battery
    Row {
        id: batteryRow
        spacing: 5
        visible: typeof battery !== "undefined" && battery.percent !== undefined
        anchors.verticalCenter: parent.verticalCenter

        // Battery Percentage Icon (replace with actual image)
        Image {
            id: batteryIcon
            source: (typeof battery !== "undefined" && battery.charging) ? "icons/battery-charging.svg" : "icons/battery-full.svg"
            width: 24
            height: 24
            fillMode: Image.PreserveAspectFit
            anchors.verticalCenter: parent.verticalCenter
        }
    }

    // Keyboard Layout
    Image {
        id: keyboardIcon
        source: "icons/keyboard.svg" // zamijeni s ikonom layouta ako želiš dinamično
        width: 24
        height: 24
        //visible: typeof keyboard !== "undefined" && keyboard.layouts.length > 1
        anchors.verticalCenter: parent.verticalCenter
        scale: mouseArea.containsMouse ? 1.4 : 1.0

        Behavior on scale {
            NumberAnimation { duration: 120 }
        }
        MouseArea {
            anchors.fill: parent
            id: mouseArea
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                if (!root) return;

                root.keyboardVisible = !root.keyboardVisible

                if (root.keyboardVisible) {
                    passwordField.forceActiveFocus()
                } else {
                    passwordField.focus = false
                }
            }
		}
    }

    // Suspend
    Image {
        id: suspendIcon
        source: "icons/suspend.svg"
        width: 24
        height: 24
        anchors.verticalCenter: parent.verticalCenter
scale: mouseAreasuspend.containsMouse ? 1.4 : 1.0

Behavior on scale {
    NumberAnimation { duration: 120 }
}
        MouseArea {
            anchors.fill: parent
            id: mouseAreasuspend
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sddm.suspend()
        }
    }

    // Restart
    Image {
        id: restartIcon
        source: "icons/reboot.svg"
        width: 24
        height: 24
        anchors.verticalCenter: parent.verticalCenter
scale: mouseArearestart.containsMouse ? 1.4 : 1.0

Behavior on scale {
    NumberAnimation { duration: 120 }
}
        MouseArea {
            anchors.fill: parent
            id: mouseArearestart
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sddm.reboot()
        }
    }

    // Shutdown
    Image {
        id: shutdownIcon
        source: "icons/shutdown.svg"
        width: 24
        height: 24
        anchors.verticalCenter: parent.verticalCenter
scale: mouseAreashutdown.containsMouse ? 1.4 : 1.0

Behavior on scale {
    NumberAnimation { duration: 120 }
}
        MouseArea {
            anchors.fill: parent
            id: mouseAreashutdown
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sddm.powerOff()
        }
    }
}
