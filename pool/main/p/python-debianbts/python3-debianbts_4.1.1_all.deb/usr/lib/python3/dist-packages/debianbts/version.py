"""Version module of debianbts."""

__version__ = "4.1.1"
