package URI::scp;

use strict;
use warnings;

our $VERSION = '5.30';

use parent 'URI::ssh';

1;
